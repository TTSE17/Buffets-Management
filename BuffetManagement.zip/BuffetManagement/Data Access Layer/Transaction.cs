﻿namespace Data_Access_Layer;

public class Transaction
{
    public int Id { get; set; }

    public decimal Value { get; set; }

    public string UserId { get; set; } = null!;
    public User User { get; set; } = null!;

    public int BuffetId { get; set; }
    public Buffet Buffet { get; set; } = null!;

    public string Description { get; set; } = null!;

    public DateTime Date { get; set; } = default;
}