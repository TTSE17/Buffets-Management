﻿using System.ComponentModel.DataAnnotations.Schema;

namespace Data_Access_Layer;

public class WorkerOrder
{
    public int Id { get; set; }
    public int WorkerId { get; set; }
    public Worker Worker { get; set; } = null!;

    public int BuffetId { get; set; }

    public Buffet Buffet { get; set; } = null!;
    public decimal TotalCost { get; set; }
    public int StatusId { get; set; }
    public DateTime CreatedDate { get; set; }

    public List<WorkerOrderDetail> OrderDetails { get; set; } = [];

    [NotMapped]
    public OrderStatus Status
    {
        get => (OrderStatus)StatusId;
        set => StatusId = (int)value;
    }
}