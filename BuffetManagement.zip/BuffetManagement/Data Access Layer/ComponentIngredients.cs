﻿namespace Data_Access_Layer;

public class ComponentIngredients
{
    public int Id { get; set; }
    public int ComponentId { get; set; }

    public int IngredientId { get; set; }
    public Item Ingredient { get; set; } = null!;
}