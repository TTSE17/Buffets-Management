﻿namespace Data_Access_Layer;

public class ItemPriceHistory
{
    public int Id { get; set; }

    public int ItemId { get; set; }
    public Item Item { get; set; } = null!;

    public int? BuffetId { get; set; }
    public Buffet? Buffet { get; set; } = null!;

    public decimal? Cost { get; set; }
    public decimal? Price { get; set; }

    public DateTime CreatedDate { get; set; }
}