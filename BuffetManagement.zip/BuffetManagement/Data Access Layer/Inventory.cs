﻿namespace Data_Access_Layer;

public class Inventory
{
    public int Id { get; set; }

    public int ItemId { get; set; }
    public Item Item { get; set; } = null!;

    public int ItemPriceHistoryId { get; set; }

    public int BuffetId { get; set; }
    public Buffet Buffet { get; set; } = null!;

    public int ByWorkerId { get; set; }

    public decimal OpenQuantity { get; set; }
    public decimal ClosedQuantity { get; set; }

    public DateTime LastUpdate { get; set; }

    public decimal? SpoilageAmount { get; set; } = null;
}