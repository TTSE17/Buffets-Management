﻿namespace Data_Access_Layer;

public enum UnitName
{
    Box = 1,
    Piece = 4,
    Gram
}