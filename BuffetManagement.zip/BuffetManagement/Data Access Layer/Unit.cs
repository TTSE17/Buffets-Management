﻿using System.ComponentModel.DataAnnotations.Schema;

namespace Data_Access_Layer;

public class Unit
{
    public int Id { get; set; }
        
    public int UnitNameId { get; set; }

    public int Type { get; set; }

    [NotMapped]
    public UnitName UnitName
    {
        get => (UnitName)UnitNameId;
        set => UnitNameId = (int)value;
    }
}