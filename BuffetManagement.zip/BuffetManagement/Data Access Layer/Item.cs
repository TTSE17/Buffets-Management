﻿namespace Data_Access_Layer;

public class Item
{
    public int Id { get; set; }

    public string Name { get; set; } = null!;

    public string? Description { get; set; }

    public string? ImageUrl { get; set; }

    public int CategoryId { get; set; }
    public Category Category { get; set; } = null!;

    public int UnitId { get; set; }
    public Unit Unit { get; set; } = null!;

    public bool IsForSale { get; set; }

    public DateTime CreatedDate { get; set; }

    // public bool IsDeleted { get; set; }

    public List<ItemPriceHistory> ItemPriceHistories { get; set; } = [];
}