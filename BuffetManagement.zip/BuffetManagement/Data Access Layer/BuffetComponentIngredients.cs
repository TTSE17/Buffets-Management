﻿namespace Data_Access_Layer;

public class BuffetComponentIngredients
{
    public int Id { get; set; }

    public int ComponentId { get; set; }

    public int IngredientId { get; set; }
    public Item Ingredient { get; set; } = null!;

    public int BuffetId { get; set; }
    public Buffet Buffet { get; set; } = null!;

    public decimal Cost { get; set; }
    public decimal Amount { get; set; }

    public DateTime CreatedDate { get; set; } = DateTime.Now;
}