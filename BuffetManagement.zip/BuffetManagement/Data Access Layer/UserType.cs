﻿namespace Data_Access_Layer;

public enum UserType
{
    User,
    Admin,
    Worker
}