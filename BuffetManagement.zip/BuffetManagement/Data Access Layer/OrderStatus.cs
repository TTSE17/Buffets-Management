﻿namespace Data_Access_Layer;

public enum OrderStatus
{
    Pending = 1,
    Preparing = 2,
    Completed = 3,
    Canceled = 4,
}