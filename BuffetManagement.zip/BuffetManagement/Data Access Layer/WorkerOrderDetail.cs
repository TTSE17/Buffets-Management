﻿namespace Data_Access_Layer;

public class WorkerOrderDetail
{
    public int Id { get; set; }
    public int WorkerOrderId { get; set; }
    public WorkerOrder WorkerOrder { get; set; } = null!;
    public int ItemId { get; set; }
    public Item Item { get; set; } = null!;
    public int Quantity { get; set; }
    public int ItemPriceHistoryId { get; set; }
}