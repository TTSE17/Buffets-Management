﻿using System.ComponentModel.DataAnnotations.Schema;

namespace Data_Access_Layer;

public class CustomerOrder
{
    public int Id { get; init; }
    public string UserId { get; init; } = null!;
    public User User { get; init; } = null!;
    public int BuffetId { get; init; }
    public Buffet Buffet { get; init; } = null!;
    public decimal TotalCost { get; init; }
    public int StatusId { get; set; }
    public DateTime CreatedDate { get; set; }

    public List<CustomerOrderDetail> OrderDetails { get; init; } = [];

    [NotMapped]
    public OrderStatus Status
    {
        get => (OrderStatus)StatusId;
        set => StatusId = (int)value;
    }
}