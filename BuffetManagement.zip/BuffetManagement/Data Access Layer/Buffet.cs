﻿using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace Data_Access_Layer;

[Index("Name", IsUnique = true)]
public class Buffet
{
    public int Id { get; set; }

    public string Name { get; set; }

    public DateTime StartDate { get; set; } = DateTime.Now;

    public string Location { get; set; }

    public int StatusId { get; set; }

    public decimal BoxValue { get; set; } = 0;

    [NotMapped]
    public BuffetStatus Status
    {
        get => (BuffetStatus)StatusId;
        init => StatusId = (int)value;
    }
}