﻿namespace Data_Access_Layer;

public enum ComponentType
{
    Sandwich,
    Dish
}