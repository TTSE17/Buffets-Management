﻿namespace Data_Access_Layer;

public class Complaint
{
    public int Id { get; set; }

    public string UserId { get; set; } = null!;

    public User User { get; set; } = null!;

    public int BuffetId { get; set; }

    public Buffet Buffet { get; set; } = null!;

    public string Type { get; set; } = null!; // : Food Quality - Service - Hygiene - Other ...

    public string Status { get; set; } = null!; // : New - Investigating - Resolved - Closed

    public string Title { get; set; } = null!;

    public string Description { get; set; } = null!;

    public DateTime CreatedDate { get; set; } = DateTime.Now;
}