﻿namespace Data_Access_Layer;

public class Supplier
{
    public int Id { get; set; }

    public string Name { get; set; } = null!;
    
    public string Category { get; set; } = null!;

    public string Number { get; set; } = null!;

    public string? Email { get; set; }

    public string? Address { get; set; }

    public DateTime StartDate { get; set; } = DateTime.Now;

    public string? Notes { get; set; }
}