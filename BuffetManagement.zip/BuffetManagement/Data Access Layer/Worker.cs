﻿namespace Data_Access_Layer;

public class Worker
{
    public int Id { get; set; }

    public string UserId { get; set; }
    public User User { get; set; } = null!;

    public int BuffetId { get; set; }

    public Buffet Buffet { get; set; } = null!;

    public DateTime HireDate { get; set; } = DateTime.Now;
}