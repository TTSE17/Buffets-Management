﻿namespace Data_Access_Layer;

public enum BuffetStatus
{
    Closed = 0,
    Open
}