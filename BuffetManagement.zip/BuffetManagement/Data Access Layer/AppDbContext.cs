﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace Data_Access_Layer;

public class AppDbContext(DbContextOptions<AppDbContext> options) : IdentityDbContext(options)
{
    public DbSet<Buffet> Buffets { get; set; }

    public new DbSet<User> Users { get; set; }

    public DbSet<Worker> Workers { get; set; }

    public DbSet<Category> Categories { get; set; }

    public DbSet<Unit> Units { get; set; }

    public DbSet<Item> Items { get; set; }

    public DbSet<ItemPriceHistory> ItemPriceHistory { get; set; }

    public DbSet<Inventory> Inventories { get; set; }

    public DbSet<ComponentIngredients> ComponentIngredients { get; set; }

    public DbSet<BuffetComponentIngredients> BuffetComponentIngredients { get; set; }

    public DbSet<CustomerOrder> CustomerOrders { get; set; }

    public DbSet<CustomerOrderDetail> CustomerOrderDetails { get; set; }

    public DbSet<WorkerOrder> WorkerOrders { get; set; }

    public DbSet<WorkerOrderDetail> WorkerOrderDetails { get; set; }

    public DbSet<Dish> Dishes { get; set; }

    public DbSet<Supplier> Suppliers { get; set; }

    public DbSet<Complaint> Complaints { get; set; }

    public DbSet<DishSale> DishSales { get; set; }

    public DbSet<Transaction> Transactions { get; set; }

    public DbSet<Notification> Notifications { get; set; }


    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);
        modelBuilder.Entity<Category>().ToTable("Categories");
    }
}