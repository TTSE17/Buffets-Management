﻿namespace Data_Access_Layer;

public class DishSale
{
    public int Id { get; set; }

    public int DishId { get; set; }
    public Dish Dish { get; set; } = null!;

    public int Count { get; set; }

    public DateTime CreatedDate { get; set; } = DateTime.Now;

    public decimal Cost { get; set; }
    public decimal Price { get; set; }
}