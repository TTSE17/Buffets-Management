﻿using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.AspNetCore.Identity;

namespace Data_Access_Layer;

public class User : IdentityUser
{
    public bool IsActive { get; set; } = true;

    public string Address { get; set; }

    public string Type { get; set; }

    public string? FCM { get; set; }

    [NotMapped]
    public UserType UserType
    {
        get => !Enum.TryParse(Type, out UserType result) ? UserType.User : result;
        set => Type = value.ToString();
    }
}