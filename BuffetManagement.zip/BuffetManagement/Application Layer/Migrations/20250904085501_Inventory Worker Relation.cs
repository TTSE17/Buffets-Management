﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Application_Layer.Migrations
{
    /// <inheritdoc />
    public partial class InventoryWorkerRelation : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "WorkerId",
                table: "Inventories",
                type: "int",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_Inventories_WorkerId",
                table: "Inventories",
                column: "WorkerId");

            migrationBuilder.AddForeignKey(
                name: "FK_Inventories_Workers_WorkerId",
                table: "Inventories",
                column: "WorkerId",
                principalTable: "Workers",
                principalColumn: "Id");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Inventories_Workers_WorkerId",
                table: "Inventories");

            migrationBuilder.DropIndex(
                name: "IX_Inventories_WorkerId",
                table: "Inventories");

            migrationBuilder.DropColumn(
                name: "WorkerId",
                table: "Inventories");
        }
    }
}
