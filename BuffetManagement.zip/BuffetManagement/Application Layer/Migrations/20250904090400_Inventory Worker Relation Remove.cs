﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Application_Layer.Migrations
{
    /// <inheritdoc />
    public partial class InventoryWorkerRelationRemove : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
        

            migrationBuilder.DropIndex(
                name: "IX_Inventories_ByWorkerId",
                table: "Inventories");

            migrationBuilder.AlterColumn<int>(
                name: "ByWorkerId",
                table: "Inventories",
                type: "int",
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldNullable: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<int>(
                name: "ByWorkerId",
                table: "Inventories",
                type: "int",
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int");

            migrationBuilder.CreateIndex(
                name: "IX_Inventories_ByWorkerId",
                table: "Inventories",
                column: "ByWorkerId");

            migrationBuilder.AddForeignKey(
                name: "FK_Inventories_Workers_ByWorkerId",
                table: "Inventories",
                column: "ByWorkerId",
                principalTable: "Workers",
                principalColumn: "Id");
        }
    }
}
