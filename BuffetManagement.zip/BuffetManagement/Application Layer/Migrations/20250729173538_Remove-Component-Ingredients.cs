﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Application_Layer.Migrations
{
    /// <inheritdoc />
    public partial class RemoveComponentIngredients : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "BuffetComponentIngredients");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "BuffetComponentIngredients",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    BuffetId = table.Column<int>(type: "int", nullable: false),
                    ComponentIngredientId = table.Column<int>(type: "int", nullable: false),
                    Amount = table.Column<int>(type: "int", nullable: false),
                    Cost = table.Column<decimal>(type: "decimal(18,2)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_BuffetComponentIngredients", x => x.Id);
                    table.ForeignKey(
                        name: "FK_BuffetComponentIngredients_Buffets_BuffetId",
                        column: x => x.BuffetId,
                        principalTable: "Buffets",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_BuffetComponentIngredients_ComponentIngredients_ComponentIngredientId",
                        column: x => x.ComponentIngredientId,
                        principalTable: "ComponentIngredients",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_BuffetComponentIngredients_BuffetId",
                table: "BuffetComponentIngredients",
                column: "BuffetId");

            migrationBuilder.CreateIndex(
                name: "IX_BuffetComponentIngredients_ComponentIngredientId",
                table: "BuffetComponentIngredients",
                column: "ComponentIngredientId");
        }
    }
}
