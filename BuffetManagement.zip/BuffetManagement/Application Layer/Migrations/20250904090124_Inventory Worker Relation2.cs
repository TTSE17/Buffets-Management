﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Application_Layer.Migrations
{
    /// <inheritdoc />
    public partial class InventoryWorkerRelation2 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
        
            migrationBuilder.DropIndex(
                name: "IX_Inventories_WorkerId",
                table: "Inventories");

            migrationBuilder.DropColumn(
                name: "WorkerId",
                table: "Inventories");

            migrationBuilder.AlterColumn<int>(
                name: "ByWorkerId",
                table: "Inventories",
                type: "int",
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int");

            migrationBuilder.CreateIndex(
                name: "IX_Inventories_ByWorkerId",
                table: "Inventories",
                column: "ByWorkerId");

            migrationBuilder.AddForeignKey(
                name: "FK_Inventories_Workers_ByWorkerId",
                table: "Inventories",
                column: "ByWorkerId",
                principalTable: "Workers",
                principalColumn: "Id");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Inventories_Workers_ByWorkerId",
                table: "Inventories");

            migrationBuilder.DropIndex(
                name: "IX_Inventories_ByWorkerId",
                table: "Inventories");

            migrationBuilder.AlterColumn<int>(
                name: "ByWorkerId",
                table: "Inventories",
                type: "int",
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldNullable: true);

            migrationBuilder.AddColumn<int>(
                name: "WorkerId",
                table: "Inventories",
                type: "int",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_Inventories_WorkerId",
                table: "Inventories",
                column: "WorkerId");

            migrationBuilder.AddForeignKey(
                name: "FK_Inventories_Workers_WorkerId",
                table: "Inventories",
                column: "WorkerId",
                principalTable: "Workers",
                principalColumn: "Id");
        }
    }
}
