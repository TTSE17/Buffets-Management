﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Application_Layer.Migrations
{
    /// <inheritdoc />
    public partial class ComponentsIngredients : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "BuffetComponents",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ComponentId = table.Column<int>(type: "int", nullable: false),
                    BuffetId = table.Column<int>(type: "int", nullable: false),
                    Count = table.Column<int>(type: "int", nullable: false),
                    Cost = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    Price = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    TotalCost = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    Date = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_BuffetComponents", x => x.Id);
                    table.ForeignKey(
                        name: "FK_BuffetComponents_Buffets_BuffetId",
                        column: x => x.BuffetId,
                        principalTable: "Buffets",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_BuffetComponents_Items_ComponentId",
                        column: x => x.ComponentId,
                        principalTable: "Items",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "ComponentIngredients",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ComponentId = table.Column<int>(type: "int", nullable: false),
                    IngredientId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ComponentIngredients", x => x.Id);
                    table.ForeignKey(
                        name: "FK_ComponentIngredients_Items_IngredientId",
                        column: x => x.IngredientId,
                        principalTable: "Items",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "BuffetComponentIngredients",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ComponentIngredientId = table.Column<int>(type: "int", nullable: false),
                    BuffetId = table.Column<int>(type: "int", nullable: false),
                    Cost = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    Amount = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_BuffetComponentIngredients", x => x.Id);
                    table.ForeignKey(
                        name: "FK_BuffetComponentIngredients_Buffets_BuffetId",
                        column: x => x.BuffetId,
                        principalTable: "Buffets",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_BuffetComponentIngredients_ComponentIngredients_ComponentIngredientId",
                        column: x => x.ComponentIngredientId,
                        principalTable: "ComponentIngredients",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_BuffetComponentIngredients_BuffetId",
                table: "BuffetComponentIngredients",
                column: "BuffetId");

            migrationBuilder.CreateIndex(
                name: "IX_BuffetComponentIngredients_ComponentIngredientId",
                table: "BuffetComponentIngredients",
                column: "ComponentIngredientId");

            migrationBuilder.CreateIndex(
                name: "IX_BuffetComponents_BuffetId",
                table: "BuffetComponents",
                column: "BuffetId");

            migrationBuilder.CreateIndex(
                name: "IX_BuffetComponents_ComponentId",
                table: "BuffetComponents",
                column: "ComponentId");

            migrationBuilder.CreateIndex(
                name: "IX_ComponentIngredients_IngredientId",
                table: "ComponentIngredients",
                column: "IngredientId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "BuffetComponentIngredients");

            migrationBuilder.DropTable(
                name: "BuffetComponents");

            migrationBuilder.DropTable(
                name: "ComponentIngredients");
        }
    }
}
