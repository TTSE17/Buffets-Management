﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Application_Layer.Migrations
{
    /// <inheritdoc />
    public partial class WastedAmount : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "IsWasted",
                table: "Inventories");

            migrationBuilder.AddColumn<decimal>(
                name: "WastedAmount",
                table: "Inventories",
                type: "decimal(18,2)",
                nullable: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "WastedAmount",
                table: "Inventories");

            migrationBuilder.AddColumn<bool>(
                name: "IsWasted",
                table: "Inventories",
                type: "bit",
                nullable: false,
                defaultValue: false);
        }
    }
}
