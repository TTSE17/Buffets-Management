﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Application_Layer.Migrations
{
    /// <inheritdoc />
    public partial class BuffetIdPriceHistory : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "BuffetId",
                table: "ItemPriceHistory",
                type: "int",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_ItemPriceHistory_BuffetId",
                table: "ItemPriceHistory",
                column: "BuffetId");

            migrationBuilder.AddForeignKey(
                name: "FK_ItemPriceHistory_Buffets_BuffetId",
                table: "ItemPriceHistory",
                column: "BuffetId",
                principalTable: "Buffets",
                principalColumn: "Id");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_ItemPriceHistory_Buffets_BuffetId",
                table: "ItemPriceHistory");

            migrationBuilder.DropIndex(
                name: "IX_ItemPriceHistory_BuffetId",
                table: "ItemPriceHistory");

            migrationBuilder.DropColumn(
                name: "BuffetId",
                table: "ItemPriceHistory");
        }
    }
}
