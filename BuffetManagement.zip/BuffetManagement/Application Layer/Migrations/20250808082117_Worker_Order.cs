﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Application_Layer.Migrations
{
    /// <inheritdoc />
    public partial class Worker_Order : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_CustomerOrders_AspNetUsers_UserId",
                table: "CustomerOrders"); 

            migrationBuilder.AlterColumn<string>(
                name: "UserId",
                table: "CustomerOrders",
                type: "nvarchar(450)",
                nullable: false,
                defaultValue: "",
                oldClrType: typeof(string),
                oldType: "nvarchar(450)",
                oldNullable: true);

            migrationBuilder.CreateTable(
                name: "WorkerOrders",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    WorkerId = table.Column<int>(type: "int", nullable: false),
                    BuffetId = table.Column<int>(type: "int", nullable: false),
                    TotalCost = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    StatusId = table.Column<int>(type: "int", nullable: false),
                    CreatedDate = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_WorkerOrders", x => x.Id);
                    table.ForeignKey(
                        name: "FK_WorkerOrders_Workers_WorkerId",
                        column: x => x.WorkerId,
                        principalTable: "Workers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "WorkerOrderDetails",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    WorkerOrderId = table.Column<int>(type: "int", nullable: false),
                    ItemId = table.Column<int>(type: "int", nullable: false),
                    Quantity = table.Column<int>(type: "int", nullable: false),
                    ItemPriceHistoryId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_WorkerOrderDetails", x => x.Id);
                    table.ForeignKey(
                        name: "FK_WorkerOrderDetails_Items_ItemId",
                        column: x => x.ItemId,
                        principalTable: "Items",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_WorkerOrderDetails_WorkerOrders_WorkerOrderId",
                        column: x => x.WorkerOrderId,
                        principalTable: "WorkerOrders",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_WorkerOrderDetails_ItemId",
                table: "WorkerOrderDetails",
                column: "ItemId");

            migrationBuilder.CreateIndex(
                name: "IX_WorkerOrderDetails_WorkerOrderId",
                table: "WorkerOrderDetails",
                column: "WorkerOrderId");

            migrationBuilder.CreateIndex(
                name: "IX_WorkerOrders_WorkerId",
                table: "WorkerOrders",
                column: "WorkerId");

            migrationBuilder.AddForeignKey(
                name: "FK_CustomerOrders_AspNetUsers_UserId",
                table: "CustomerOrders",
                column: "UserId",
                principalTable: "AspNetUsers",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_CustomerOrders_AspNetUsers_UserId",
                table: "CustomerOrders");

            migrationBuilder.DropTable(
                name: "WorkerOrderDetails");

            migrationBuilder.DropTable(
                name: "WorkerOrders");

            migrationBuilder.AlterColumn<string>(
                name: "UserId",
                table: "CustomerOrders",
                type: "nvarchar(450)",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(450)");

            migrationBuilder.AddColumn<int>(
                name: "CustomerId",
                table: "CustomerOrders",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddForeignKey(
                name: "FK_CustomerOrders_AspNetUsers_UserId",
                table: "CustomerOrders",
                column: "UserId",
                principalTable: "AspNetUsers",
                principalColumn: "Id");
        }
    }
}
