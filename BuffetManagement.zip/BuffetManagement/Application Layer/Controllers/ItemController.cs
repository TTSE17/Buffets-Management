﻿using Business_Layer.Consts;
using Business_Layer.Dto.Item;
using Business_Layer.IServices;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Application_Layer.Controllers;

[Route("api/[controller]")]
[ApiController]
public class ItemController(IItemService itemService) : ControllerBase
{
    [HttpPost("GetAll")]
    [Authorize(Roles = $"{Roles.Admin},{Roles.Worker}")]
    public async Task<IActionResult> GetAll(ItemPagedRequestDto dto)
    {
        var search = dto.Search?.Trim();
        var categoryId = dto.CategoryId;

        var response = await itemService.GetAll(dto, i =>
            (string.IsNullOrEmpty(search) || i.Name.Contains(search)) &&
            (!categoryId.HasValue || i.CategoryId == categoryId.Value));

        return Ok(response);
    }

    [HttpGet("GetAllSandwiches")]
    [Authorize(Roles = $"{Roles.Admin},{Roles.Worker}")]
    public async Task<IActionResult> GetAllSandwiches()
    {
        var response = await itemService.GetAllSandwiches();

        return Ok(response);
    }

    [HttpPost("GetAllExceptSandwiches")]
    [Authorize(Roles = $"{Roles.Admin},{Roles.Worker}")]
    public async Task<IActionResult> GetAllExceptSandwiches(ItemPagedRequestDto dto)
    {
        var search = dto.Search?.Trim();
        var categoryId = dto.CategoryId;

        var response = await itemService.GetAll(dto, i =>
            i.CategoryId != 4 &&
            (string.IsNullOrEmpty(search) || i.Name.Contains(search)) &&
            (!categoryId.HasValue || i.CategoryId == categoryId.Value)
        );

        return Ok(response);
    }

    [HttpPost("GetAllByCategoryId")]
    [Authorize(Roles = $"{Roles.Admin},{Roles.Worker}")]
    public async Task<IActionResult> GetAllByCategoryId(int id, ItemPagedRequestDto dto)
    {
        var search = dto.Search?.Trim();

        var response = await itemService.GetAll(dto, i =>
            i.CategoryId == id &&
            (string.IsNullOrEmpty(search) || i.Name.Contains(search)));

        return Ok(response);
    }

    [HttpPost("GetAllAreForSale")]
    [Authorize(Roles = $"{Roles.Admin},{Roles.Worker}")]
    public async Task<IActionResult> GetAllAreForSale(ItemPagedRequestDto dto)
    {
        var search = dto.Search?.Trim();
        var categoryId = dto.CategoryId;

        var response = await itemService.GetAll(dto, i =>
            i.IsForSale &&
            (string.IsNullOrEmpty(search) || i.Name.Contains(search)) &&
            (!categoryId.HasValue || i.CategoryId == categoryId.Value));

        return Ok(response);
    }

    [HttpPost("GetAllRaws")]
    [Authorize(Roles = $"{Roles.Admin},{Roles.Worker}")]
    public async Task<IActionResult> GetAllRaws(ItemPagedRequestDto dto)
    {
        var response = await itemService.GetAll(dto, i => i.Category.Name == "Raw");

        return Ok(response);
    }

    [HttpGet("GetItemDetails")]
    [Authorize]
    public async Task<IActionResult> GetItemDetails(int id)
    {
        var response = await itemService.GetItemDetails(id);

        if (response.Success)
        {
            return Ok(response);

            // return Ok(new { response.Result, Profit = response.Result!.Price - response.Result.Cost, success = true });
        }

        return NotFound(response);
    }

    [HttpPost("Add")]
    [Authorize(Roles = Roles.Admin)]
    public async Task<IActionResult> Create(CreateItemDto dto)
    {
        var response = await itemService.Add(dto);

        if (response.Success)
            return Ok(response);

        return BadRequest(response);
    }

    [HttpPost("Update")]
    [Authorize(Roles = Roles.Admin)]
    public async Task<IActionResult> Update(UpdateItemDto dto)
    {
        var response = await itemService.Update(dto);

        if (response.Success)
            return Ok(response);

        return BadRequest(response);
    }

    [HttpDelete("Delete")]
    [Authorize(Roles = Roles.Admin)]
    public async Task<IActionResult> Delete(int id)
    {
        var response = await itemService.Delete(id);

        if (response.Success)
            return Ok(response);

        return BadRequest(response);
    }
}

// https://res.cloudinary.com/dtygdmyyv/image/upload/v1754561938/k2zwro8ktnbzyos698uk.jpg
// https://res.cloudinary.com/dtygdmyyv/image/upload/v1755169058/ta2aljqsqgm46r2ciixx.jpg