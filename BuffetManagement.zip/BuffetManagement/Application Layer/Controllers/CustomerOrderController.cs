﻿using System.Linq.Expressions;
using Business_Layer.Consts;
using Business_Layer.Dto;
using Business_Layer.Dto.CustomerOrder;
using Business_Layer.IServices;
using Data_Access_Layer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Application_Layer.Controllers;

[Route("api/[controller]")]
[ApiController]
public class CustomerOrderController(ICustomerOrderService customerOrderService) : ControllerBase
{
    [HttpPost("Add")]
    [Authorize(Roles = Roles.Customer)]
    public async Task<IActionResult> Add(CreateCustomerOrderDto dto)
    {
        var response = await customerOrderService.Add(dto);

        if (response.Success)
            return Ok(response);

        return BadRequest(response);
    }

    [HttpPost("GetAll")]
    [Authorize(Roles = Roles.Admin)]
    public async Task<IActionResult> GetAll(CustomerOrderPagedRequestDto dto)
    {
        var filterResponse = CheckFilters(dto);

        if (!filterResponse.Success)
        {
            return BadRequest(filterResponse.Error);
        }

        var response = await customerOrderService.GetAll(dto, filterResponse.Result);

        return Ok(response);
    }

    [HttpPost("GetAllInBuffet")]
    [Authorize(Roles = $"{Roles.Admin},{Roles.Worker}")]
    public async Task<IActionResult> GetAllInBuffet(int buffetId, CustomerOrderPagedRequestDto dto)
    {
        var filterResponse = CheckFilters(dto);

        if (!filterResponse.Success)
        {
            return BadRequest(filterResponse.Error);
        }

        var response = await customerOrderService.GetAll(dto, o => o.BuffetId == buffetId);

        return Ok(response);
    }

    [HttpPost("GetAllByCustomerId")]
    [Authorize(Roles = $"{Roles.Admin},{Roles.Customer}")]
    public async Task<IActionResult> GetAllByCustomerId(string customerId, CustomerOrderPagedRequestDto dto)
    {
        var filterResponse = CheckFilters(dto);

        if (!filterResponse.Success)
        {
            return BadRequest(filterResponse.Error);
        }

        var response = await customerOrderService.GetAll(dto, o => o.UserId == customerId);

        return Ok(response);
    }

    [HttpGet("GetDetails")]
    [Authorize]
    public async Task<IActionResult> GetDetails(int orderId)
    {
        var response = await customerOrderService.GetDetails(orderId);

        return Ok(response);
    }

    [HttpPost("SetStatus")]
    [Authorize(Roles = Roles.Worker)]
    public async Task<IActionResult> SetStatus(SetStatusDto dto)
    {
        var status = dto.Status;

        if (string.IsNullOrWhiteSpace(status))
        {
            return BadRequest("Status is required.");
        }

        if (!Enum.TryParse(status, ignoreCase: true, out OrderStatus orderStatus))
        {
            return BadRequest("Invalid status. Valid values are: Pending, Preparing, Completed, Canceled.");
        }

        var response = await customerOrderService.SetStatus(dto.OrderId, dto.WorkerId, orderStatus);

        if (response.Success)
            return Ok(response);

        return BadRequest(response);
    }

    private static Response<Expression<Func<CustomerOrder, bool>>?> CheckFilters(CustomerOrderPagedRequestDto dto)
    {
        var response = new Response<Expression<Func<CustomerOrder, bool>>?>();

        var userName = dto.UserName;
        var buffetName = dto.BuffetName;
        var date = dto.Date;

        var status = dto.OrderStatus;

        var orderStatus = OrderStatus.Preparing;

        if (!string.IsNullOrEmpty(status))
        {
            if (!Enum.TryParse(dto.OrderStatus, ignoreCase: true, out orderStatus))
            {
                response.Error = "Invalid status. Valid values are: Pending, Preparing, Completed, Canceled.";

                return response;
            }
        }

        Expression<Func<CustomerOrder, bool>> expression = o =>
            (string.IsNullOrEmpty(userName) || o.User.UserName!.Contains(userName)) &&
            (string.IsNullOrEmpty(buffetName) || o.Buffet.Name.Contains(buffetName)) &&
            (string.IsNullOrEmpty(status) || o.StatusId == (int)orderStatus) &&
            (!date.HasValue || o.CreatedDate >= date.Value);

        response.Result = expression;

        response.Success = true;

        return response;
    }
}