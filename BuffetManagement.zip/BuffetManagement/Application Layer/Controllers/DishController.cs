﻿using Business_Layer.Consts;
using Business_Layer.Dto.Dish;
using Business_Layer.IServices;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Application_Layer.Controllers;

[Route("api/[controller]")]
[ApiController]
[Authorize(Roles = Roles.Admin)]
public class DishController(IDishService dishService) : ControllerBase
{
    [HttpPost("GetAll")]
    public async Task<IActionResult> GetAll(DishPagedRequestDto dto)
    {
        var name = dto.Name?.Trim();
        var dishId = dto.DishId;

        var response = await dishService.GetAll(d =>
            (string.IsNullOrEmpty(name) || d.Name.Contains(name)) &&
            (!dishId.HasValue || d.Id == dishId.Value));

        return Ok(response);
    }

    [HttpPost("Add")]
    public async Task<IActionResult> Create(CreateUpdateDishDto dto)
    {
        var response = await dishService.Add(dto);

        if (response.Success)
            return Ok(response);

        return BadRequest(response);
    }

    [HttpPost("Update")]
    public async Task<IActionResult> Update(CreateUpdateDishDto dto)
    {
        var response = await dishService.Update(dto);

        if (response.Success)
            return Ok(response);

        return BadRequest(response);
    }

    [HttpGet("GetDetails")]
    public async Task<IActionResult> GetItemDetails(int id)
    {
        var response = await dishService.GetDetails(id);

        if (response.Success)
        {
            return Ok(response);
        }

        return NotFound(response);
    }

    [HttpDelete("Delete")]
    public async Task<IActionResult> Delete(int id)
    {
        var response = await dishService.Delete(id);

        if (response.Success)
            return Ok(response);

        return BadRequest(response);
    }

    [HttpPost("AddSale/{dishId}")]
    public async Task<IActionResult> AddSale(int dishId, int count)
    {
        var response = await dishService.AddSale(dishId, count);

        if (response.Success)
            return Ok(response);

        return BadRequest(response);
    }

    [HttpPost("Statistics")]
    public IActionResult Statistics(DishPagedRequestDto dto)
    {
        var date = dto.Date;

        var response = dishService.Statistics(d => !date.HasValue || d.CreatedDate >= date.Value);

        if (response.Success)
            return Ok(response);

        return BadRequest(response);
    }
}