﻿ using Business_Layer.Consts;
 using Business_Layer.Dto.User;
using Business_Layer.IServices;
using Data_Access_Layer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Application_Layer.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AdminController(IUserService userService) : ControllerBase
    {
        [HttpPost("Login")]
        public async Task<IActionResult> Login(LoginDto request)
        {
            var response = await userService.Login(request, UserType.Admin);

            if (response.Success)
                return Ok(response);

            return Unauthorized(response);
        }

        [HttpGet("Logout")]
        [Authorize(Roles = Roles.Admin)]
        public async Task<IActionResult> Logout()
        {
            await userService.Logout();

            return Ok();
        }
    }
}