﻿using Business_Layer.Consts;
using Business_Layer.Dto.WorkerOrder;
using Business_Layer.IServices;
using Data_Access_Layer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Application_Layer.Controllers;

[Route("api/[controller]")]
[ApiController]
public class WorkerOrderController(IWorkerOrderService workerOrderService) : ControllerBase
{
    [HttpPost("Add")]
    [Authorize(Roles = Roles.Worker)]
    public async Task<IActionResult> Add(CreateWorkerOrderDto dto)
    {
        var response = await workerOrderService.Add(dto);

        if (response.Success)
            return Ok(response);

        return BadRequest(response);
    }

    [HttpPost("GetAll")]
    [Authorize(Roles = Roles.Admin)]
    public async Task<IActionResult> GetAll(WorkerOrderPagedRequestDto dto)
    {
        var buffetName = dto.BuffetName;
        var date = dto.Date;
        var status = dto.OrderStatus;

        var orderStatus = OrderStatus.Preparing;

        if (!string.IsNullOrEmpty(status))
        {
            if (!Enum.TryParse(dto.OrderStatus, ignoreCase: true, out orderStatus))
            {
                return BadRequest("Invalid status. Valid values are: Pending, Preparing, Completed, Canceled.");
            }
        }

        var response = await workerOrderService.GetAll(dto.PageNumber, o =>
            (string.IsNullOrEmpty(buffetName) || o.Buffet.Name.Contains(buffetName)) &&
            (string.IsNullOrEmpty(status) || o.StatusId == (int)orderStatus) &&
            (!date.HasValue || o.CreatedDate >= date.Value)
            );

        return Ok(response);
    }

    [HttpGet("GetAllInBuffet")]
    [Authorize(Roles = $"{Roles.Admin},{Roles.Worker}")]
    public async Task<IActionResult> GetAllInBuffet(int buffetId)
    {
        var response = await workerOrderService.GetAll(0, o => o.BuffetId == buffetId);

        return Ok(response);
    }

    [HttpGet("GetAllByWorkerId")]
    [Authorize(Roles = $"{Roles.Admin},{Roles.Worker}")]
    public async Task<IActionResult> GetAllByWorkerId(int workerId)
    {
        var response = await workerOrderService.GetAll(0, o => o.WorkerId == workerId);

        return Ok(response);
    }

    [HttpGet("GetDetails")]
    [Authorize]
    public async Task<IActionResult> GetDetails(int orderId)
    {
        var response = await workerOrderService.GetDetails(orderId);

        if(response.Success)
            return Ok(response);
        
        return NotFound(response);
    }

    [HttpGet("SetStatus/{id}")]
    [Authorize(Roles = Roles.Admin)]
    public async Task<IActionResult> SetStatus(int id, string status)
    {
        if (string.IsNullOrWhiteSpace(status))
        {
            return BadRequest("Status is required.");
        }

        if (!Enum.TryParse(status, ignoreCase: true, out OrderStatus orderStatus) ||
            !Enum.IsDefined(orderStatus) || orderStatus == OrderStatus.Preparing)
        {
            return BadRequest("Invalid status. Valid values are: Pending , Completed, Canceled.");
        }

        var response = await workerOrderService.SetStatus(id, orderStatus);

        if (response.Success)
            return Ok(response);

        return BadRequest(response);
    }
}