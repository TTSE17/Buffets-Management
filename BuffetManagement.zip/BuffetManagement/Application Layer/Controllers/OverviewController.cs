﻿using Business_Layer.Consts;
using Business_Layer.Dto.Overview;
using Business_Layer.IServices;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Application_Layer.Controllers;

[Route("api/[controller]")]
[ApiController]
[Authorize(Roles = Roles.Admin)]
public class OverviewController(IOverviewService overviewService) : ControllerBase
{
    [HttpPost("DashboardOverview")]
    public async Task<IActionResult> DashboardOverview(OverviewPagedRequestDto dto)
    {
        var response = await overviewService.GetDashboardOverview(dto);

        if (response.Success)
            return Ok(response);

        return BadRequest();
    }
    
    [HttpPost("Report")]
    public async Task<IActionResult> Report(OverviewPagedRequestDto dto)
    {
        var response = await overviewService.Report(dto);

        if (response.Success)
            return Ok(response);

        return BadRequest();
    }
}