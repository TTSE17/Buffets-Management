﻿using Business_Layer.Consts;
using Business_Layer.Dto.Component;
using Business_Layer.IServices;
using Data_Access_Layer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Application_Layer.Controllers;

[Route("api/[controller]")]
[ApiController]
public class ComponentController(IComponentService componentService) : ControllerBase
{
    [HttpPost("CreateSandwich")]
    [Authorize(Roles = Roles.Admin)]
    public async Task<IActionResult> Create(CreateComponentDto dto)
    {
        var response = await componentService.Create(dto, ComponentType.Sandwich);

        if (response.Success)
            return Ok(response);

        return BadRequest(response);
    }

    [HttpPost("CalculateCostComponent")]
    [Authorize(Roles = Roles.Worker)]
    public async Task<IActionResult> CalculateCost(CalculateCostComponentDto dto)
    {
        if (dto.Ingredients.Count == 0 || dto.Count == 0)
            return BadRequest();

        var response = await componentService.CalculateCost(dto);

        if (response.Success)
            return Ok(response);

        return BadRequest(response);
    }

    [HttpPost("Add")]
    [Authorize(Roles = Roles.Worker)]
    public async Task<IActionResult> Add(AddComponentDto dto)
    {
        if (dto.Ingredients.Count == 0 || dto.Count == 0)
            return BadRequest();

        var response = await componentService.Add(dto);

        if (response.Success)
            return Ok(response);

        return BadRequest(response);
    }

    [HttpPost("Update/{id}")]
    [Authorize(Roles = Roles.Admin)]
    public async Task<IActionResult> Update(int id, CreateComponentDto dto)
    {
        if (dto.Ingredients.Count == 0)
            return BadRequest();

        var response = await componentService.Update(id, dto);

        if (response.Success)
            return Ok(response);

        return BadRequest(response);
    }

    [HttpGet("GetComponentDetails")]
    [Authorize]
    public async Task<IActionResult> GetComponentDetails(int componentId)
    {
        if (componentId == 0)
            return BadRequest();

        var response = await componentService.GetComponentDetails(componentId);

        if (response.Success)
            return Ok(response);

        return BadRequest(response);
    }
}