﻿using Business_Layer.Consts;
using Business_Layer.Dto.Inventory;
using Business_Layer.IServices;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Application_Layer.Controllers;

[Route("api/[controller]")]
[ApiController]
public class InventoryController(IInventoryService inventoryService) : ControllerBase
{
    [HttpPost("GetAll")]
    [Authorize(Roles = $"{Roles.Admin},{Roles.Worker}")]
    public async Task<IActionResult> GetAll(InventoryPagedRequestDto dto)
    {
        var categoryId = dto.CategoryId;
        var buffetId = dto.BuffetId;
        var date = dto.Date;
        var spoilageAmount = dto.SpoilageAmount;

        var response = await inventoryService.GetAll(dto, i =>
            (!buffetId.HasValue || i.BuffetId == buffetId.Value) &&
            (!categoryId.HasValue || i.Item.CategoryId == categoryId.Value) &&
            (!spoilageAmount.HasValue || i.SpoilageAmount >= spoilageAmount.Value) &&
            (!date.HasValue || i.LastUpdate >= date.Value)
        );

        return Ok(response);
    }

    [HttpPost("GetItemHistory/{itemId}")]
    [Authorize(Roles = $"{Roles.Admin},{Roles.Worker}")]
    public async Task<IActionResult> GetItemHistory(int itemId, InventoryPagedRequestDto dto)
    {
        var categoryId = dto.CategoryId;
        var buffetId = dto.BuffetId;
        var date = dto.Date;
        var spoilageAmount = dto.SpoilageAmount;

        var response = await inventoryService.GetItemHistory(dto, i =>
            (!buffetId.HasValue || i.BuffetId == buffetId.Value) &&
            i.ItemId == itemId &&
            (!categoryId.HasValue || i.Item.CategoryId == categoryId.Value) &&
            (!spoilageAmount.HasValue || i.SpoilageAmount >= spoilageAmount.Value) &&
            (!date.HasValue || i.LastUpdate >= date.Value)
        );

        return Ok(response);
    }

    [HttpGet("GetAllByCategoryId")]
    [Authorize(Roles = $"{Roles.Admin},{Roles.Worker}")]
    public async Task<IActionResult> GetAllByCategoryId(int? buffetId, int categoryId)
    {
        var dto = new InventoryPagedRequestDto();

        var response = await inventoryService.GetAll(dto, i =>
            i.BuffetId == buffetId && i.Item.CategoryId == categoryId);

        return Ok(response);
    }

    [HttpGet("GetAllAreForSellingInBuffet")]
    [Authorize]
    public async Task<IActionResult> GetAllAreForSellingInBuffet(int? buffetId)
    {
        var dto = new InventoryPagedRequestDto();

        var response = await inventoryService.GetAll(dto, i => i.BuffetId == buffetId && i.Item.IsForSale);

        return Ok(response);
    }

    [HttpGet("GetAllAreForSellingInBuffetByCategoryId")]
    [Authorize]
    public async Task<IActionResult> GetAllAreForSellingInBuffetByCategoryId(int? buffetId, int categoryId)
    {
        var dto = new InventoryPagedRequestDto();

        var response = await inventoryService.GetAll(dto, i =>
            i.BuffetId == buffetId && i.Item.IsForSale && i.Item.CategoryId == categoryId);

        return Ok(response);
    }

    [HttpPost("Add")]
    [Authorize(Roles = Roles.Worker)]
    public async Task<IActionResult> Create(CreateInventoryDto dto)
    {
        var response = await inventoryService.Add(dto);

        if (response.Success)
            return Ok(response);

        return BadRequest(response);
    }

    // [HttpPost("Update")]
    // public async Task<IActionResult> Update(UpdateInventoryDto dto)
    // {
    //     var response = await inventoryService.Update(dto);
    //
    //     if (response.Success)
    //         return Ok(response);
    //
    //     return BadRequest(response);
    // }

    [HttpDelete("Delete")]
    [Authorize(Roles = Roles.Worker)]
    public async Task<IActionResult> Delete(int id)
    {
        var response = await inventoryService.Delete(id);

        if (response.Success)
            return Ok(response);

        return BadRequest(response);
    }

    [HttpPost("AddSpoilageItem")]
    [Authorize(Roles = Roles.Worker)]
    public async Task<IActionResult> AddSpoilageItem(AddSpoilageItemDto dto)
    {
        var response = await inventoryService.AddSpoilageItem(dto);

        if (response.Success)
            return Ok(response);

        return BadRequest(response);
    }
}