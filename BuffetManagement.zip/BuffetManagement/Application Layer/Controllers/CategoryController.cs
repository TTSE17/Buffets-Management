﻿using Business_Layer.Consts;
using Business_Layer.Dto.Category;
using Business_Layer.IServices;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Application_Layer.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CategoryController(ICategoryService categoryService) : ControllerBase
    {
        [HttpGet("GetAll")]
        [Authorize]
        public async Task<IActionResult> GetAll()
        {
            var response = await categoryService.GetAll();

            return Ok(response);
        }

        [HttpPost("Add")]
        [Authorize(Roles = Roles.Admin)]
        public async Task<IActionResult> Create(GetCategoryDto dto)
        {
            var response = await categoryService.Add(dto);

            if (response.Success)
                return Ok(response);

            return BadRequest(response);
        }

        [HttpPost("Update")]
        [Authorize(Roles = Roles.Admin)]
        public async Task<IActionResult> Update(GetCategoryDto dto)
        {
            if (dto.Id == 4) return BadRequest("You do not have access to update this category");

            var response = await categoryService.Update(dto);

            if (response.Success)
                return Ok(response);

            return BadRequest(response);
        }

        [HttpDelete("Delete")]
        [Authorize(Roles = Roles.Admin)]
        public async Task<IActionResult> Delete(int id)
        {
            if (id == 4) return BadRequest("You do not have access to delete this category");

            var response = await categoryService.Delete(id);

            if (response.Success)
                return Ok(response);

            return BadRequest(response);
        }
    }
}