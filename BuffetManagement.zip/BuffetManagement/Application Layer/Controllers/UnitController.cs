﻿using Business_Layer.Consts;
using Business_Layer.IServices;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Application_Layer.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UnitController(IUnitService unitService) : ControllerBase
    {
        [HttpGet("GetAll")]
        [Authorize(Roles = $"{Roles.Admin},{Roles.Worker}")]
        public async Task<IActionResult> GetAll()
        {
            var response = await unitService.GetAll();

            return Ok(response);
        }
    }
}