﻿using Business_Layer.Consts;
using Business_Layer.Dto;
using Business_Layer.Dto.Buffet;
using Business_Layer.IServices;
using Data_Access_Layer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Application_Layer.Controllers;

[Route("api/[controller]")]
[ApiController]
public class BuffetController(IBuffetService buffetService) : ControllerBase
{
    [HttpPost("GetAll")]
    [Authorize(Roles = Roles.Admin)]
    public async Task<IActionResult> GetAll(BuffetPagedRequestDto dto)
    {
        var name = dto.Name?.Trim();
        var buffetId = dto.BuffetId;

        var response = await buffetService.GetAllOverview(b =>
            (string.IsNullOrEmpty(name) || b.Name.Contains(name)) &&
            (!buffetId.HasValue || b.Id == buffetId.Value));

        return Ok(response);
    }

    [HttpGet("GetOpenBuffets")]
    [Authorize(Roles = $"{Roles.Admin},{Roles.Customer}")]
    public async Task<IActionResult> GetOpenBuffets()
    {
        var response = await buffetService.GetAll(b => b.StatusId == (int)BuffetStatus.Open);

        return Ok(response);
    }

    [HttpPost("Add")]
    [Authorize(Roles = Roles.Admin)]
    public async Task<IActionResult> Create(CreateBuffetDto dto)
    {
        if (!Enum.TryParse(dto.Status, ignoreCase: true, out BuffetStatus _))
        {
            var r = new Response<object>
            {
                Error = "Invalid status. Valid values are: Open, Closed."
            };

            return BadRequest(r);
        }

        var response = await buffetService.Add(dto);

        if (response.Success)
            return Ok(response);

        return BadRequest(response);
    }

    [HttpPost("Update")]
    [Authorize(Roles = Roles.Admin)]
    public async Task<IActionResult> Update(UpdateBuffetDto dto)
    {
        var response = await buffetService.Update(dto);

        if (response.Success)
            return Ok(response);

        return BadRequest(response);
    }

    [HttpDelete("Delete")]
    [Authorize(Roles = Roles.Admin)]
    public async Task<IActionResult> Delete(int id)
    {
        var response = await buffetService.Delete(id);

        if (response.Success)
            return Ok(response);

        return BadRequest(response);
    }
}