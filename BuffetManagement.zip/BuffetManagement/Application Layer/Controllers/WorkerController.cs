﻿using Business_Layer.Consts;
using Business_Layer.Dto;
using Business_Layer.Dto.User;
using Business_Layer.Dto.Worker;
using Business_Layer.IServices;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Application_Layer.Controllers;

[Route("api/[controller]")]
[ApiController]
public class WorkerController(IWorkerService workerService, IUserService userService) : ControllerBase
{
    [HttpPost("GetAll")]
    [Authorize(Roles = Roles.Admin)]
    public async Task<IActionResult> GetAll(WorkerPagedRequestDto dto)
    {
        var workerName = dto.WorkerName?.Trim();
        var buffetId = dto.BuffetId;

        var workers = await workerService.GetAll(dto, w =>
            (string.IsNullOrEmpty(workerName) || w.User.UserName!.Contains(workerName)) &&
            (!buffetId.HasValue || w.BuffetId == buffetId.Value)
        );

        return Ok(workers);
    }

    [HttpPost("Register")]
    [Authorize(Roles = Roles.Admin)]
    public async Task<IActionResult> Register(CreateWorkerDto request)
    {
        if (request.User.Password is null || request.User.Password.Trim() == "")
        {
            var res = new Response<string>
            {
                Error = "Password is required"
            };

            return BadRequest(res);
        }

        var response = await workerService.Register(request);

        if (response.Success)
            return Ok(response);

        return BadRequest(response);
    }

    [HttpPost("Login")]
    public async Task<IActionResult> Login(LoginDto request)
    {
        var response = await workerService.Login(request);

        if (response.Success)
            return Ok(response);

        return Unauthorized(response);
    }

    [HttpGet("Logout")]
    [Authorize(Roles = Roles.Worker)]
    public async Task<IActionResult> Logout()
    {
        await userService.Logout();

        return Ok();
    }

    [HttpPost("Update")]
    [Authorize(Roles = Roles.Admin)]
    public async Task<IActionResult> Update(UpdateWorkerDto dto)
    {
        var response = await workerService.Update(dto);

        if (response.Success)
            return Ok(response);

        return BadRequest(response);
    }

    [HttpDelete("Delete")]
    [Authorize(Roles = Roles.Admin)]
    public async Task<IActionResult> Delete(int id)
    {
        var response = await workerService.Delete(id);
        
        if (response.Success)
            return Ok(response);
        
        return BadRequest(response);
    }
}