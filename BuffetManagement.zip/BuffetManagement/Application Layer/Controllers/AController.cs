﻿using Business_Layer.Consts;
using Business_Layer.Dto;
using Business_Layer.IServices;
using Business_Layer.Services;
using Data_Access_Layer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Application_Layer.Controllers;

// [Route("api/[controller]")]
// [ApiController]
public class AController(
    RoleManager<IdentityRole> roleManager,
    UserManager<User> userManager,
    IFirebaseService firebaseService) : ControllerBase
{
    private async Task<IActionResult> RolesAsync()
    {
        var x = Test();

        var roles = new[] { "Admin", "Worker", "Customer" };

        if (roleManager.Roles.Any())
            return BadRequest();

        foreach (var role in roles)
        {
            if (!await roleManager.RoleExistsAsync(role))
                await roleManager.CreateAsync(new IdentityRole(role));
        }

        return await Task.FromResult<IActionResult>(Ok());
    }

    private Response<Tuple<decimal, decimal>> Test()
    {
        var ret = new Response<Tuple<decimal, decimal>>();
        ret.Result = new Tuple<decimal, decimal>(1.5m, 1.5m);
        return ret;
    }

    private async Task<IActionResult> GetUsersWithRoles()
    {
        var users = userManager.Users.ToList();
        var usersWithRoles = new List<UserWithRolesDto>();

        foreach (var user in users)
        {
            var roles = await userManager.GetRolesAsync(user);
            usersWithRoles.Add(new UserWithRolesDto
            {
                Id = user.Id,
                UserName = user.UserName,
                Email = user.Email,
                Roles = roles.ToList()
            });
        }

        return Ok(usersWithRoles);
    }

    private class UserWithRolesDto
    {
        public string Id { get; set; }
        public string UserName { get; set; }
        public string Email { get; set; }
        public List<string> Roles { get; set; } = new List<string>();
    }

    private async Task<IActionResult> AssignRolesBasedOnType()
    {
        var users = await userManager.Users
            .Where(u => u.IsActive) // Only active users if needed
            .ToListAsync();

        var results = new List<string>();

        foreach (var user in users)
        {
            var currentRoles = await userManager.GetRolesAsync(user);
            if (currentRoles.Any())
            {
                results.Add($"User {user.UserName} already has roles: {string.Join(", ", currentRoles)}");
                continue;
            }

            // Assign role based on UserType
            var roleToAssign = user.UserType switch
            {
                UserType.Admin => Roles.Admin,
                UserType.Worker => Roles.Worker,
                UserType.User => Roles.Customer,
                _ => Roles.Customer
            };

            var result = await userManager.AddToRoleAsync(user, roleToAssign);

            if (result.Succeeded)
            {
                results.Add($"Assigned role '{roleToAssign}' to user {user.UserName} (Type: {user.UserType})");
            }
            else
            {
                results.Add(
                    $"Failed to assign role to {user.UserName}: {string.Join(", ", result.Errors.Select(e => e.Description))}");
            }
        }

        return Ok(results);
    }

    [HttpGet("a")]
    [Authorize(Roles = "Admin")]
    public IActionResult AdminEndpoint()
    {
        return Ok();
    }

    [Authorize(Roles = Roles.Worker)]
    [HttpGet("w")]
    public IActionResult WorkerEndpoint()
    {
        return Ok();
    }

    [HttpGet("c")]
    [Authorize(Roles = Roles.Customer)]
    public async Task<IActionResult> CustomerEndpoint()
    {
        // Get the CURRENTLY logged in user
        var user = await userManager.GetUserAsync(User);
        return Ok(await userManager.IsInRoleAsync(user, Roles.Customer));
    }

    [HttpGet("Notfication")]
    public async Task<IActionResult> Send()
    {
        try
        {
            var messageId = await firebaseService.SendNotificationAsync(
                // "dfS9z-BD6jX9CP9wWmgeSC:APA91bGE6xNEZeLe_EZjQjc18_byefLM3-QY3lAAJpkqbqgkhqwqdsvNkCw4Od1sWkFvM2CD_GKa8eB65iVT7uN6yOzQZlNmOnmq1iaTeq-d9Q-DjEcroXA",
                "c5V4yArbz-kGy043gLWQXe:APA91bEC291HVhXUT__xoHyslrfR8baEcptH2fKMDxJl6J1h8PrZjqp--wvmZ4SX5QKrFdnxDpnFJDM29AceXeuSpWvmvkUbIHOa9E_bU082l0zpoE0hswk",
                "FIFA 2023!", " ة");
        }
        catch (Exception e)
        {
            return BadRequest(e.Message);
        }

        return Ok();
    }
}