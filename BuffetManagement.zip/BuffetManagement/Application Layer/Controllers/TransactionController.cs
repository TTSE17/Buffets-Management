﻿using Business_Layer.Consts;
using Business_Layer.Dto.Transaction;
using Business_Layer.IServices;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Application_Layer.Controllers;

[Route("api/[controller]")]
[ApiController]
public class TransactionController(ITransactionService transactionService) : ControllerBase
{
    [HttpPost("GetAll")]
    [Authorize(Roles = Roles.Admin)]
    public async Task<IActionResult> GetAll(TransactionPagedRequestDto dto)
    {
        var buffetName = dto.BuffetName?.Trim();
        var userName = dto.UserName?.Trim();
        var date = dto.Date;

        var response = await transactionService.GetAll(dto, t =>
            (string.IsNullOrEmpty(buffetName) || t.Buffet.Name.Contains(buffetName)) &&
            (string.IsNullOrEmpty(userName) || t.User.UserName!.Contains(userName)) &&
            (!date.HasValue || t.Date >= date.Value)
        );

        return Ok(response);
    }

    [HttpPost("Add")]
    [Authorize(Roles = $"{Roles.Admin},{Roles.Worker}")]
    public async Task<IActionResult> Create(GetTransactionDto dto)
    {
        var response = await transactionService.Add(dto);

        if (response.Success)
            return Ok(response);

        return BadRequest(response);
    }
}