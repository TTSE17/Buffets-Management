﻿using Business_Layer.IServices;
using Business_Layer.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Application_Layer.Controllers;

[Route("api/[controller]")]
[ApiController]
public class NotificationController(INotificationService notificationService) : ControllerBase
{
    [HttpPost("GetAll/{userId}")]
    [Authorize]
    public async Task<IActionResult> GetAll(string userId)
    {
        var response = await notificationService.GetAllNotifications(userId);

        return Ok(response);
    }
}