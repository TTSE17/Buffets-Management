﻿using Business_Layer.Consts;
using Business_Layer.Dto.Supplier;
using Business_Layer.IServices;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Application_Layer.Controllers;

[Route("api/[controller]")]
[ApiController]
[Authorize(Roles = Roles.Admin)]
public class SupplierController(ISupplierService supplierService) : ControllerBase
{
    [HttpPost("GetAll")]
    public async Task<IActionResult> GetAll(SupplierPagedRequestDto dto)
    {
        var name = dto.Name?.Trim();
        var supplierId = dto.SupplierId;
        var category = dto.Category?.Trim();
        var number = dto.Number?.Trim();

        var response = await supplierService.GetAll(d =>
            (string.IsNullOrEmpty(name) || d.Name.Contains(name)) &&
            (!supplierId.HasValue || d.Id == supplierId.Value) &&
            (string.IsNullOrEmpty(category) || d.Category.Contains(category)) &&
            (string.IsNullOrEmpty(number) || d.Number.Contains(number))
        );

        return Ok(response);
    }

    [HttpPost("Add")]
    public async Task<IActionResult> Create(CreateUpdateSupplierDto dto)
    {
        var response = await supplierService.Add(dto);

        if (response.Success)
            return Ok(response);

        return BadRequest(response);
    }

    [HttpPost("Update")]
    public async Task<IActionResult> Update(CreateUpdateSupplierDto dto)
    {
        var response = await supplierService.Update(dto);

        if (response.Success)
            return Ok(response);

        return BadRequest(response);
    }

    [HttpDelete("Delete")]
    public async Task<IActionResult> Delete(int id)
    {
        var response = await supplierService.Delete(id);

        if (response.Success)
            return Ok(response);

        return BadRequest(response);
    }
}