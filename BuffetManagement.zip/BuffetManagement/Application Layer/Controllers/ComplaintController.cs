﻿using Business_Layer.Consts;
using Business_Layer.Dto.Complaint;
using Business_Layer.IServices;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Application_Layer.Controllers;

[Route("api/[controller]")]
[ApiController]
public class ComplaintController(IComplaintService complaintService) : ControllerBase
{
    [HttpPost("GetAll")]
    [Authorize(Roles = $"{Roles.Admin},{Roles.Customer}")]
    public async Task<IActionResult> GetAll(ComplaintPagedRequestDto dto)
    {
        var buffetName = dto.BuffetName?.Trim();
        var status = dto.Status?.Trim();
        var type = dto.Type?.Trim();
        var userId = dto.UserId?.Trim();

        var startDate = dto.StartDate;

        var endDate = dto.EndDate.HasValue
            ? dto.EndDate.Value.Date.AddDays(1).AddTicks(-1) // End of day
            : DateTime.Now.Date;

        var response = await complaintService.GetAll(c =>
            (string.IsNullOrEmpty(buffetName) || c.Buffet.Name.Contains(buffetName)) &&
            (string.IsNullOrEmpty(status) || c.Status == status) &&
            (string.IsNullOrEmpty(userId) || c.UserId == userId) &&
            (!startDate.HasValue || (c.CreatedDate <= endDate && c.CreatedDate >= startDate.Value)) &&
            (string.IsNullOrEmpty(type) || c.Type == type)
        );

        return Ok(response);
    }

    [HttpPost("Add")]
    [Authorize(Roles = Roles.Customer)]
    public async Task<IActionResult> Create(GetComplaintDto dto)
    {
        var response = await complaintService.Add(dto);

        if (response.Success)
            return Ok(response);

        return BadRequest(response);
    }

    [HttpGet("SetStatus/{id}")]
    [Authorize(Roles = Roles.Admin)]
    public async Task<IActionResult> SetStatus(int id, string status)
    {
        if (string.IsNullOrWhiteSpace(status))
        {
            return BadRequest("Status is required.");
        }

        var response = await complaintService.SetStatus(id, status);

        if (response.Success)
            return Ok(response);

        return BadRequest(response);
    }

    // [HttpPost("Update")]
    // public async Task<IActionResult> Update(GetComplaintDto dto)
    // {
    //     var response = await complaintService.Update(dto);
    //
    //     if (response.Success)
    //         return Ok(response);
    //
    //     return BadRequest(response);
    // }

    [HttpGet("GetDetails")]
    [Authorize(Roles = $"{Roles.Admin},{Roles.Customer}")]
    public async Task<IActionResult> GetItemDetails(int id)
    {
        var response = await complaintService.GetDetails(id);

        if (response.Success)
        {
            return Ok(response);
        }

        return NotFound(response);
    }

    [HttpDelete("Delete")]
    [Authorize(Roles = Roles.Customer)]
    public async Task<IActionResult> Delete(int id)
    {
        var response = await complaintService.Delete(id);

        if (response.Success)
            return Ok(response);

        return BadRequest(response);
    }
}