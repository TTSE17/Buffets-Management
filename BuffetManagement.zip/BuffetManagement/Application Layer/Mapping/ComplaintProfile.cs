﻿using AutoMapper;
using Business_Layer.Dto.Complaint;
using Data_Access_Layer;

namespace Application_Layer.Mapping;

public class ComplaintProfile : Profile
{
    public ComplaintProfile()
    {
        CreateMap<Complaint, GetComplaintDto>().ReverseMap();
    }
}