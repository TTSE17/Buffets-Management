﻿using AutoMapper;
using Business_Layer.Dto.Unit;
using Data_Access_Layer;

namespace Application_Layer.Mapping
{
    public class UnitProfile : Profile
    {
        public UnitProfile()
        {
            CreateMap<Unit, GetUnitDto>();
        }
    }
}