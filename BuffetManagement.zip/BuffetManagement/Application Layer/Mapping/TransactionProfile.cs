﻿using AutoMapper;
using Business_Layer.Dto.Transaction;
using Data_Access_Layer;

namespace Application_Layer.Mapping;

public class TransactionProfile : Profile
{
    public TransactionProfile()
    {
        CreateMap<Transaction, GetTransactionDto>().ReverseMap();
    }
}