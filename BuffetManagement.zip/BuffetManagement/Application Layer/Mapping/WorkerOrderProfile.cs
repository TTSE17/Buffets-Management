﻿using AutoMapper;
using Business_Layer.Dto.Worker;
using Business_Layer.Dto.WorkerOrder;
using Data_Access_Layer;

namespace Application_Layer.Mapping;

public class WorkerOrderProfile : Profile
{
    public WorkerOrderProfile()
    {
        CreateMap<WorkerOrder, GetWorkerOrderDto>().ReverseMap();

        CreateMap<CreateWorkerOrderDto, WorkerOrder>();

        CreateMap<WorkerOrderDetail, GetWorkerOrderDetailDto>().ReverseMap();
    }
}