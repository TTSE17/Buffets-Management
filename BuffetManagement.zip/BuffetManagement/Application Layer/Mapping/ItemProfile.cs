﻿using AutoMapper;
using Business_Layer.Dto.Item;
using Data_Access_Layer;

namespace Application_Layer.Mapping;

public class ItemProfile : Profile
{
    public ItemProfile()
    {
        CreateMap<Item, GetItemDto>().ReverseMap();

        CreateMap<CreateItemDto, Item>();
        
        CreateMap<CreateSimpleItemDto, Item>();

        CreateMap<UpdateItemDto, Item>();
    }
}