﻿using AutoMapper;
using Business_Layer.Dto.ItemPriceHistory;
using Data_Access_Layer;

namespace Application_Layer.Mapping;

public class ItemPriceHistoryProfile : Profile
{
    public ItemPriceHistoryProfile()
    {
        CreateMap<ItemPriceHistory, GetItemPriceHistoryDto>().ReverseMap();
    }
}