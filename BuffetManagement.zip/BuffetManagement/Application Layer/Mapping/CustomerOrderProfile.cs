﻿using AutoMapper;
 using Business_Layer.Dto.CustomerOrder;
 using Data_Access_Layer;

namespace Application_Layer.Mapping;

public class CustomerOrderProfile : Profile
{
    public CustomerOrderProfile()
    {
        CreateMap<CustomerOrder, GetCustomerOrderDto>().ReverseMap();

        CreateMap<CreateCustomerOrderDto, CustomerOrder>();

        CreateMap<CustomerOrderDetail, GetCustomerOrderDetailDto>().ReverseMap();
    }
}