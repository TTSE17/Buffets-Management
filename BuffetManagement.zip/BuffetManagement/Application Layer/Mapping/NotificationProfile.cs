﻿using AutoMapper;
using Business_Layer.Dto.Notification;
using Data_Access_Layer;

namespace Application_Layer.Mapping;

public class NotificationProfile : Profile
{
    public NotificationProfile()
    {
        CreateMap<Notification, GetNotificationDto>().ReverseMap();
    }
}