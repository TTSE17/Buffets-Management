﻿using AutoMapper;
using Business_Layer.Dto.Inventory;
using Data_Access_Layer;

namespace Application_Layer.Mapping;

public class InventoryProfile : Profile
{
    public InventoryProfile()
    {
        CreateMap<Inventory, GetInventoryDto>().ReverseMap();

        CreateMap<CreateInventoryDto, Inventory>();
        
        CreateMap<AddSpoilageItemDto, Inventory>();

        CreateMap<UpdateInventoryDto, Inventory>();   
    }
}