﻿using AutoMapper;
using Business_Layer.Dto.Supplier;
using Data_Access_Layer;

namespace Application_Layer.Mapping;

public class SupplierProfile: Profile
{
    public SupplierProfile()
    {
        CreateMap<Supplier, GetSupplierDto>().ReverseMap();
        CreateMap<CreateUpdateSupplierDto, Supplier>();
    }
}