﻿using AutoMapper;
using Business_Layer.Dto.Category;
using Data_Access_Layer;

namespace Application_Layer.Mapping
{
     public class CategoryProfile : Profile
    {
         public CategoryProfile()
        {
            CreateMap<Category, GetCategoryDto>().ReverseMap();
        }
    }
}