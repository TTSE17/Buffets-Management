﻿using AutoMapper;
using Business_Layer.Dto.User;
using Data_Access_Layer;

namespace Application_Layer.Mapping
{
    public class UserProfile : Profile
    {
        public UserProfile()
        {
            CreateMap<CreateUserDto, User>();
            CreateMap<User, GetUserDto>();
        }
    }
}