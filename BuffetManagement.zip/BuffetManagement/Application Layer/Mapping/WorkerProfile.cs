﻿using AutoMapper;
using Business_Layer.Dto.Worker;
using Data_Access_Layer;

namespace Application_Layer.Mapping
{
    public class WorkerProfile : Profile
    {
        public WorkerProfile()
        {
            CreateMap<CreateWorkerDto, Worker>();
            CreateMap<Worker, GetWorkerDto>().ForMember(des => des.BuffetName,
                opt =>
                    opt.MapFrom(src => src.Buffet.Name));
        }
    }
}