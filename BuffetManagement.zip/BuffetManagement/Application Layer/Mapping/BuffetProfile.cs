﻿using AutoMapper;
using Business_Layer.Dto.Buffet;
using Data_Access_Layer;

namespace Application_Layer.Mapping
{
     public class BuffetProfile : Profile
    {
         public BuffetProfile()
        {
            CreateMap<Buffet, GetBuffetDto>().ReverseMap();
            CreateMap<CreateBuffetDto, Buffet>();
            CreateMap<UpdateBuffetDto, Buffet>();
        }
    }
}