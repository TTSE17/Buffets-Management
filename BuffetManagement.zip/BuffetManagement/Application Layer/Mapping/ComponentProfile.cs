﻿using AutoMapper;
using Business_Layer.Dto.Item;
using Data_Access_Layer;

namespace Application_Layer.Mapping;

public class ComponentProfile : Profile
{
    public ComponentProfile()
    {
        // CreateMap<Item, GetItemDto>().ReverseMap();

        // CreateMap<cre, Item>();
    }
}