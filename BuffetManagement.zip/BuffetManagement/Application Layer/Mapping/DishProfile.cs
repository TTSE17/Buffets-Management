﻿using AutoMapper;
using Business_Layer.Dto.Dish;
using Data_Access_Layer;

namespace Application_Layer.Mapping;

public class DishProfile : Profile
{
    public DishProfile()
    {
        CreateMap<Dish, GetDishDto>().ReverseMap();
        CreateMap<CreateUpdateDishDto, Buffet>();
    }
}