﻿using Business_Layer.IServices;
using Business_Layer.Services;

namespace Application_Layer.DependencyInjections
{
    public static class RepositoryDependencyInjection
    {
        public static IServiceCollection AddRepositoryDependencyInjection(this IServiceCollection services)
        {
            services.AddScoped<TokenService>();
            services.AddTransient<IUserService, UserService>();
            services.AddTransient<IWorkerService, WorkerService>();
            services.AddTransient<ICategoryService, CategoryService>();
            services.AddTransient<IUnitService, UnitService>();
            services.AddTransient<IBuffetService, BuffetService>();
            services.AddTransient<IItemService, ItemService>();
            services.AddTransient<IInventoryService, InventoryService>();
            services.AddTransient<IComponentService, ComponentService>();
            services.AddTransient<ICustomerOrderService, CustomerOrderService>();
            services.AddTransient<IWorkerOrderService, WorkerOrderService>();
            services.AddTransient<IDishService, DishService>();
            services.AddTransient<ISupplierService, SupplierService>();
            services.AddTransient<IComplaintService, ComplaintService>();
            services.AddTransient<ITransactionService, TransactionService>();
            services.AddTransient<IOverviewService, OverviewService>();
            services.AddTransient<IFirebaseService, FirebaseService>();
            services.AddTransient<INotificationService, NotificationService>();

            return services;
        }
    }
}