﻿using Microsoft.Extensions.Options;

namespace Application_Layer.DependencyInjections
{
    public static class ApplicationBuilderDependencyInjection
    {
        public static void AddApplicationBuilderDependencyInjection(this IApplicationBuilder app,
            IServiceProvider service)
        {
            var options = service.GetService<IOptions<RequestLocalizationOptions>>();

            app.UseRequestLocalization(options!.Value);
        }
    }
}