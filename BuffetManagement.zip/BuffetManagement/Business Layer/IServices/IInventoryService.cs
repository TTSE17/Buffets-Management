﻿using System.Linq.Expressions;
using Business_Layer.Dto;
using Business_Layer.Dto.Inventory;
using Business_Layer.Dto.Item;
using Business_Layer.Dto.Overview;
using Data_Access_Layer;

namespace Business_Layer.IServices;

public interface IInventoryService
{
    Task<Response<List<GetInventoryDto>>> GetAll(InventoryPagedRequestDto dto,
        Expression<Func<Inventory, bool>>? criteria = null);

    Task<Response<GetInventoryDto>> Add(CreateInventoryDto dto);

    // Task<Response<GetInventoryDto>> Update(UpdateInventoryDto dto);

    Task<Response<bool>> Delete(int id);

    Task<decimal?> CheckQuantity(int itemId, int buffetId);

    Task<(decimal OpenQuantity, decimal ClosedQuantity)?>
        CalculateNewQuantity(int itemId, int buffetId, decimal amount);

    Task<Response<GetItemHistoryDto>> GetItemHistory(InventoryPagedRequestDto dto,
        Expression<Func<Inventory, bool>>? criteria = null);

    Task<Response<List<GetInventoryDto>>> AddSpoilageItem(AddSpoilageItemDto dto);

    Task<(decimal TotalSales, decimal NetProfit, string TopSelling, decimal SpoilageLoss)?> Statistics(
        OverviewPagedRequestDto dto);

    Task<List<GetSellingItemDto>> GetSellingItems(OverviewPagedRequestDto dto);
}