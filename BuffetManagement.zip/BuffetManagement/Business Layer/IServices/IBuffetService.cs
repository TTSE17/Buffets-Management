﻿using System.Linq.Expressions;
using Business_Layer.Dto;
using Business_Layer.Dto.Buffet;
using Data_Access_Layer;

namespace Business_Layer.IServices
{
    public interface IBuffetService
    {
        Task<Response<List<GetBuffetDto>>> GetAll(Expression<Func<Buffet, bool>>? criteria = null);

        Task<Response<List<object>>> GetAllOverview(Expression<Func<Buffet, bool>>? criteria = null);

        Task<Response<GetBuffetDto>> Add(CreateBuffetDto dto);

        Task<Response<GetBuffetDto>> Update(UpdateBuffetDto dto);

        Task<Response<bool>> Delete(int id);

        Task<Response<GetBuffetDto>> AddValue(int buffetId, decimal value);
    }
}