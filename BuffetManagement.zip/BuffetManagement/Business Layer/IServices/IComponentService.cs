﻿using Business_Layer.Dto;
using Business_Layer.Dto.Component;
using Data_Access_Layer;

namespace Business_Layer.IServices;

public interface IComponentService
{
    Task<Response<GetComponentDto>> Create(CreateComponentDto dto, ComponentType type);

    Task<Response<object>> CalculateCost(CalculateCostComponentDto dto);

    Task<Response<object>> Add(AddComponentDto dto);

    Task<Response<GetComponentDto>> GetComponentDetails(int componentId);

    Task<Response<GetComponentDto>> Update(int componentId, CreateComponentDto dto);
}