﻿using System.Linq.Expressions;
using Business_Layer.Dto;
using Business_Layer.Dto.Complaint;
using Data_Access_Layer;

namespace Business_Layer.IServices;

public interface IComplaintService
{
    Task<Response<List<GetComplaintDto>>> GetAll(Expression<Func<Complaint, bool>>? criteria = null);

    Task<Response<GetComplaintDto>> Add(GetComplaintDto dto);

    // Task<Response<GetComplaintDto>> Update(GetComplaintDto dto);

    Task<Response<GetComplaintDto>> GetDetails(int id);
    
    Task<Response<GetComplaintDto>> SetStatus(int id, string status);

    Task<Response<bool>> Delete(int id);
}