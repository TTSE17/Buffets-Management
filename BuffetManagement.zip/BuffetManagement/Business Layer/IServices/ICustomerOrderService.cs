﻿using System.Linq.Expressions;
using Business_Layer.Dto;
using Business_Layer.Dto.CustomerOrder;
using Data_Access_Layer;

namespace Business_Layer.IServices;

public interface ICustomerOrderService
{
    Task<Response<GetCustomerOrderDto>> Add(CreateCustomerOrderDto dto);

    Task<Response<List<GetCustomerOrderDto>>> GetAll(CustomerOrderPagedRequestDto dto,
        Expression<Func<CustomerOrder, bool>>? criteria = null);

    Task<Response<GetCustomerOrderDto?>> GetDetails(int orderId);

    Task<Response<GetCustomerOrderDto>> SetStatus(int orderId, int workerId, OrderStatus status);
}