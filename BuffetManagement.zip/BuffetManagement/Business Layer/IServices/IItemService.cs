﻿using System.Linq.Expressions;
using Business_Layer.Dto;
using Business_Layer.Dto.Component;
using Business_Layer.Dto.Item;
using Business_Layer.Dto.ItemPriceHistory;
using Data_Access_Layer;

namespace Business_Layer.IServices;

public interface IItemService
{
    Task<Response<List<GetItemDto>>> GetAll(ItemPagedRequestDto dto, Expression<Func<Item, bool>>? criteria = null);

    Task<Response<List<GetItemDto>>> GetAllSandwiches();

    Task<Response<GetItemDto>> Add(CreateItemDto category);

    Task<Response<GetItemDto>> Update(UpdateItemDto category);

    Task<Response<GetComponentDto>>  GetItemDetails(int id);

    Task<Response<bool>> Delete(int id);

    Task<GetItemPriceHistoryDto?> GetLastItemPriceHistory(int itemId, int? buffetId);

    Task<GetItemPriceHistoryDto?> GetPriceHistory(int priceHistoryId);

    Task<bool> IsSandwich(int itemId);
}