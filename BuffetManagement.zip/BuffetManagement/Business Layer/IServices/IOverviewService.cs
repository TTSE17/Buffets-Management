﻿using Business_Layer.Dto;
using Business_Layer.Dto.Overview;

namespace Business_Layer.IServices;

public interface IOverviewService
{
    Task<Response<object>> GetDashboardOverview(OverviewPagedRequestDto dto);

    Task<Response<object>> Report(OverviewPagedRequestDto dto);
}