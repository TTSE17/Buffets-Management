﻿using System.Linq.Expressions;
using Business_Layer.Dto;
using Business_Layer.Dto.Transaction;
using Transaction = Data_Access_Layer.Transaction;

namespace Business_Layer.IServices;

public interface ITransactionService
{
    Task<Response<List<GetTransactionDto>>> GetAll(TransactionPagedRequestDto dto,
        Expression<Func<Transaction, bool>>? criteria = null);

    Task<Response<GetTransactionDto>> Add(GetTransactionDto dto);
}