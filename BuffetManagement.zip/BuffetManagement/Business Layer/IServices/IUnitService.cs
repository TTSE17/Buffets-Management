﻿using Business_Layer.Dto;
using Business_Layer.Dto.Unit;

namespace Business_Layer.IServices
{
    public interface IUnitService
    {
         Task<Response<List<GetUnitDto>>> GetAll();
    }
}