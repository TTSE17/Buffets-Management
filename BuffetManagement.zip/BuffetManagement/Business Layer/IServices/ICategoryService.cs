﻿using Business_Layer.Dto;
using Business_Layer.Dto.Category;

namespace Business_Layer.IServices
{
    public interface ICategoryService
    {
        Task<Response<List<GetCategoryDto>>> GetAll();

        Task<Response<GetCategoryDto>> Add(GetCategoryDto category);

        Task<Response<GetCategoryDto>> Update(GetCategoryDto category);

        Task<Response<bool>> Delete(int id);
    }
}