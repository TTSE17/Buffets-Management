﻿using System.Linq.Expressions;
using Business_Layer.Dto;
using Business_Layer.Dto.Dish;
using Data_Access_Layer;

namespace Business_Layer.IServices;

public interface IDishService
{
    Task<Response<List<GetDishDto>>> GetAll(Expression<Func<Dish, bool>>? criteria = null);

    Task<Response<GetDishDto>> Add(CreateUpdateDishDto dto);

    Task<Response<GetDishDto>> Update(CreateUpdateDishDto dto);

    Task<Response<GetDishDto>> GetDetails(int id);

    Task<Response<bool>> Delete(int id);

    Task<Response<bool>> AddSale(int dishId, int count);

    Response<object> Statistics(Expression<Func<DishSale, bool>>? criteria = null);
}