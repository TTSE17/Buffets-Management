﻿using Business_Layer.Dto;
using Business_Layer.Dto.Notification;

namespace Business_Layer.IServices;

public interface INotificationService
{
    Task<Response<List<GetNotificationDto>>> GetAllNotifications(string userId);

    Task<Response<GetNotificationDto>> Add(GetNotificationDto dto);
}