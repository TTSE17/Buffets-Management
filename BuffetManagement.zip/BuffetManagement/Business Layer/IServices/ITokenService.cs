﻿using Data_Access_Layer;

namespace Business_Layer.IServices
{
    // Token: 0x0200000B RID: 11
     public interface ITokenService
    { 
        string CreateJwtToken(User user);
    }
}