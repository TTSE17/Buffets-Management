﻿using System.Linq.Expressions;
using Business_Layer.Dto;
using Business_Layer.Dto.User;
using Business_Layer.Dto.Worker;
using Data_Access_Layer;

namespace Business_Layer.IServices
{
    public interface IWorkerService
    {
        Task<GetWorkerDto?> GetWorkerDto(int workerId);

        Task<Response<GetWorkerDto>> Register(CreateWorkerDto dto);

        Task<Response<WorkerAuthResponse>> Login(LoginDto dto);

        Task<Response<List<GetWorkerDto>>> GetAll(WorkerPagedRequestDto dto,
            Expression<Func<Worker, bool>>? criteria = null);

        Task<Response<GetWorkerDto>> Update(UpdateWorkerDto dto);

        Task<Response<bool>> Delete(int id);
    }
}