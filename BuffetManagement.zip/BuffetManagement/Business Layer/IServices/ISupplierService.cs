﻿using System.Linq.Expressions;
using Business_Layer.Dto;
using Business_Layer.Dto.Supplier;
using Data_Access_Layer;

namespace Business_Layer.IServices;

public interface ISupplierService
{
    Task<Response<List<GetSupplierDto>>> GetAll(Expression<Func<Supplier, bool>>? criteria = null);

    Task<Response<GetSupplierDto>> Add(CreateUpdateSupplierDto dto);

    Task<Response<GetSupplierDto>> Update(CreateUpdateSupplierDto dto);


    Task<Response<bool>> Delete(int id);
}