﻿using System.Linq.Expressions;
using Business_Layer.Dto;
using Business_Layer.Dto.WorkerOrder;
using Data_Access_Layer;

namespace Business_Layer.IServices;

public interface IWorkerOrderService
{
    Task<Response<GetWorkerOrderDto>> Add(CreateWorkerOrderDto dto);

    Task<Response<List<GetWorkerOrderDto>>>
        GetAll(int pageNumber, Expression<Func<WorkerOrder, bool>>? criteria = null);

    Task<Response<GetWorkerOrderDto?>> GetDetails(int orderId);

    Task<Response<GetWorkerOrderDto>> SetStatus(int id, OrderStatus status);
}