﻿using Business_Layer.Dto;
using Business_Layer.Dto.User;
using Data_Access_Layer;

namespace Business_Layer.IServices
{
    public interface IUserService
    {
        Task<Response<GetUserDto>> Register(CreateUserDto dto);

        Task<Response<AuthResponse>> Login(LoginDto dto, UserType type);

        Task<Response<GetUserDto>> Update(UpdateUserDto dto);

        Task Logout();
    }
}