﻿using Business_Layer.Dto.Buffet;
using Business_Layer.Dto.User;

namespace Business_Layer.Dto.Transaction;

public class GetTransactionDto
{
    public int Id { get; set; }

    public decimal Value { get; set; }

    public string UserId { get; set; } = null!;
    public GetUserDto? User { get; set; }

    public int BuffetId { get; set; }
    public GetBuffetDto? Buffet { get; set; } = null!;

    public string Description { get; set; } = null!;

    public DateTime Date { get; set; } = DateTime.Now;
}