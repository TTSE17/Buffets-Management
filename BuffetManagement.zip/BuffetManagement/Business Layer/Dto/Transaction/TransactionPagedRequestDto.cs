﻿namespace Business_Layer.Dto.Transaction;

public class TransactionPagedRequestDto
{
    public string? UserName { get; set; } = null;

    public string? BuffetName { get; set; } = null;

    public DateTime? Date { get; set; } = null;
    
    public int PageNumber { get; set; } = 0;
}