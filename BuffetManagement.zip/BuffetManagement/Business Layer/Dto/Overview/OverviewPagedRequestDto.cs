﻿namespace Business_Layer.Dto.Overview;

public class OverviewPagedRequestDto
{
    public int? BuffetId { get; set; } = null;

    public DateTime? StartDate { get; set; } = null;

    public DateTime? EndDate { get; set; } = null;
}