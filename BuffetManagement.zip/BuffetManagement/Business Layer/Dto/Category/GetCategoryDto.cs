﻿namespace Business_Layer.Dto.Category
{
    public class GetCategoryDto
    {
        public int Id { get; set; }

        public string Name { get; set; }
    }
}