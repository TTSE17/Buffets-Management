﻿using Business_Layer.Dto.Dish;

namespace Business_Layer.Dto.Supplier;

public class CreateUpdateSupplierDto : GetSupplierDto
{
}