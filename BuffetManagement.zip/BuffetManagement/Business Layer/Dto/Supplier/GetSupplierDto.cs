﻿using System.ComponentModel.DataAnnotations;

namespace Business_Layer.Dto.Supplier;

public class GetSupplierDto
{
    public int Id { get; set; }

    [Required] public string Name { get; set; } = null!;

    [Required] public string Category { get; set; } = null!;

    [Required] public string Number { get; set; } = null!;

    public string? Email { get; set; }

    public string? Address { get; set; }

    public DateTime StartDate { get; set; } = DateTime.Now;

    public string? Notes { get; set; }
}