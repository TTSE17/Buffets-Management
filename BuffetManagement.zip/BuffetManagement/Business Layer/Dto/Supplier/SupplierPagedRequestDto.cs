﻿namespace Business_Layer.Dto.Supplier;

public class SupplierPagedRequestDto
{
    public int? SupplierId { get; set; } = null;
    public string? Name { get; set; } = null;
    public string? Number { get; set; } = null;
    public string? Category { get; set; } = null;
}