﻿using System.ComponentModel.DataAnnotations;

namespace Business_Layer.Dto;

public class PagedRequestDto
{
    public string? Search { get; set; } = null;
    public int? CategoryId { get; set; } = null;

    [Range(1, int.MaxValue, ErrorMessage = "Please enter a number between 1 and +~")]

    public int PageNumber { get; set; } = 1;
}