﻿using System.ComponentModel.DataAnnotations;

namespace Business_Layer.Dto.WorkerOrder;

public class CreateWorkerOrderDto
{
    public string WorkerId { get; init; } = null!;
    public int BuffetId { get; init; }
    
    public DateTime CreatedDate { get; set; } = DateTime.Now;

    [MinLength(1)] public Dictionary<int, int> Items { get; set; } = new();
}