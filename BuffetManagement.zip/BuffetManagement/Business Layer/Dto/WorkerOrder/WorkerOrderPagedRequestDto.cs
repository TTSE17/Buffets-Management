﻿using System.ComponentModel.DataAnnotations;

namespace Business_Layer.Dto.WorkerOrder;

public class WorkerOrderPagedRequestDto
{
    // public string? WorkerName { get; set; } = null;
    public string? BuffetName { get; set; } = null;
    public string? OrderStatus { get; set; } = null;
    public DateTime? Date { get; set; } = null;

     public int PageNumber { get; set; } = 1;
}