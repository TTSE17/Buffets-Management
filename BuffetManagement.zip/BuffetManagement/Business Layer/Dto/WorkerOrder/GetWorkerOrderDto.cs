﻿using Business_Layer.Dto.Buffet;
using Business_Layer.Dto.CustomerOrder;
using Business_Layer.Dto.Worker;

namespace Business_Layer.Dto.WorkerOrder;

public class GetWorkerOrderDto
{
    public int Id { get; init; }
    public string WorkerId { get; init; } = null!;
    public GetWorkerDto Worker { get; init; } = null!;
    public int BuffetId { get; init; }
    public GetBuffetDto Buffet { get; init; } = null!;
    public decimal TotalCost { get; init; }
    public string Status { get; set; } = null!;
    public DateTime CreatedDate { get; set; }

    public List<GetWorkerOrderDetailDto> OrderDetails { get; set; } = [];
}