﻿namespace Business_Layer.Dto.Complaint;

public class ComplaintPagedRequestDto
{
    public string? BuffetName { get; set; } = null;
    public string? Status { get; set; } = null;
    public string? Type { get; set; } = null;
    public string? UserId { get; set; } = null;

    public DateTime? StartDate { get; set; } = null;

    public DateTime? EndDate { get; set; } = null;
}