﻿using System.ComponentModel.DataAnnotations;
using Business_Layer.Dto.Buffet;
using Business_Layer.Dto.User;

namespace Business_Layer.Dto.Complaint;

public class GetComplaintDto
{
    public int Id { get; set; }

    [Required] public string UserId { get; set; } = null!;

    public GetUserDto? User { get; set; }

    [Required] public int BuffetId { get; set; }

    public GetBuffetDto? Buffet { get; set; }

    public string Type { get; set; } = null!; // : Food Quality - Service - Hygiene - Other ...

    public string Status { get; set; } = "New"; // : New - Investigating - Resolved - Closed

    public string Title { get; set; } = null!;

    public string Description { get; set; } = null!;

    public DateTime CreatedDate { get; set; } = DateTime.Now;
}