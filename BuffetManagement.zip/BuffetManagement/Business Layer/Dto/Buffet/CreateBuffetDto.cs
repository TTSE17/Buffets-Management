﻿namespace Business_Layer.Dto.Buffet
{
    public class CreateBuffetDto
    {
        public string Name { get; set; } = null!;

        public DateTime StartDate { get; set; } = DateTime.Now;

        public string Location { get; set; } = null!;

        public string Status { get; set; } = null!;
    }
}