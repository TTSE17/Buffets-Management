﻿namespace Business_Layer.Dto.Buffet
{
    public class UpdateBuffetDto : CreateBuffetDto
    {
        public int Id { get; set; }
    }
}