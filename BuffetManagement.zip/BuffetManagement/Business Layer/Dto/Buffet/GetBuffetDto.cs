﻿namespace Business_Layer.Dto.Buffet
{
    public class GetBuffetDto
    {
        public int Id { get; set; }
        public string Name { get; set; } = null!;
        public DateTime StartDate { get; set; }

        public string Location { get; set; } = null!;

        public decimal BoxValue { get; set; }


        public string Status { get; set; } = null!;
    }
}