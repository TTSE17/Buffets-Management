﻿namespace Business_Layer.Dto.Buffet;

public class BuffetPagedRequestDto
{
    public int? BuffetId { get; set; } = null;
    public string? Name { get; set; } = null;
}