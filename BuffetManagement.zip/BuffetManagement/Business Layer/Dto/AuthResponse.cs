﻿using Business_Layer.Dto.User;

namespace Business_Layer.Dto
{
    public class AuthResponse
    {
        public string UserId { get; set; } = null!;

        public GetUserDto User { get; set; } = null!;

        public string Token { get; set; } = null!;
    }

    public class WorkerAuthResponse : AuthResponse
    {
        public int Id { get; set; }
        public int BuffetId { get; set; }
    }
}