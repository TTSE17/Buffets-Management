﻿namespace Business_Layer.Dto.Component;

public class CalculateCostComponentDto
{
    public Dictionary<int, decimal> Ingredients { get; set; } = new();

    public int Count { get; set; }

    public int BuffetId { get; set; }
}