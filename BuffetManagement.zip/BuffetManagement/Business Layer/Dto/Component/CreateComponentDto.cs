﻿using System.ComponentModel.DataAnnotations;
using Business_Layer.Dto.Item;

namespace Business_Layer.Dto.Component;

public class CreateComponentDto
{
    public CreateSimpleItemDto Component { get; set; } = null!;
    [MinLength(1)] public List<int> Ingredients { get; set; } = [];
}