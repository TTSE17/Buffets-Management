﻿using Business_Layer.Dto.Item;

namespace Business_Layer.Dto.Component;

public class GetComponentDto
{
    // public int Id { get; set; }
    
    public GetItemDto Component { get; set; } = null!;

    public List<GetItemDto> Ingredients { get; set; } = [];
}