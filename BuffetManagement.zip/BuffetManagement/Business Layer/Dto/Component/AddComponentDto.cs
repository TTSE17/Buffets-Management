﻿namespace Business_Layer.Dto.Component;

public class AddComponentDto : CalculateCostComponentDto
{
    public int ComponentId { get; set; }
    public decimal Cost { get; set; }
    public decimal Price { get; set; }
    public int WorkerId { get; set; }
}