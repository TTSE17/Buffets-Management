﻿using System.ComponentModel.DataAnnotations;

namespace Business_Layer.Dto.Worker;

public class UpdateWorkerDto : CreateWorkerDto
{
    public int Id { get; set; }
}