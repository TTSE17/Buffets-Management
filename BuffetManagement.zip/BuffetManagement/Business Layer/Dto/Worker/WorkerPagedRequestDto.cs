﻿namespace Business_Layer.Dto.Worker;

public class WorkerPagedRequestDto
{
    public int? BuffetId { get; set; } = null;

    public string? WorkerName { get; set; } = null;

    public int PageNumber { get; set; } = 0;
}