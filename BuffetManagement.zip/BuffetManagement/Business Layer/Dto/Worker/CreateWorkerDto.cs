﻿using System.ComponentModel.DataAnnotations;
using Business_Layer.Dto.User;

namespace Business_Layer.Dto.Worker
{
    public class CreateWorkerDto
    {
        public CreateUserDto User { get; set; } = null!;

        public int BuffetId { get; set; }

        public DateTime HireDate { get; set; }
    }
}