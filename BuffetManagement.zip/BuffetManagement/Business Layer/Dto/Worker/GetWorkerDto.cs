﻿using Business_Layer.Dto.User;

namespace Business_Layer.Dto.Worker
{
    public class GetWorkerDto
    {
        public string Id { get; set; } = null!;

        public GetUserDto User { get; set; }

        public int BuffetId { get; set; }

        public string BuffetName { get; set; } = null!;

        public DateTime HireDate { get; set; }
    }
}