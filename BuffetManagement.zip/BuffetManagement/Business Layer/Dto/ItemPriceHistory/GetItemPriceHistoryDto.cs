﻿namespace Business_Layer.Dto.ItemPriceHistory;

public class GetItemPriceHistoryDto
{
    public int Id { get; set; }

    public decimal? Cost { get; set; }
    public decimal? Price { get; set; }
}