﻿namespace Business_Layer.Dto.Item;

public class CreateItemDto
{
    public string Name { get; set; } = null!;

    public string? Description { get; set; }

    public string? ImageUrl { get; set; }

    public int CategoryId { get; set; }

    public int UnitId { get; set; }

    public decimal? Cost { get; set; }
    public decimal? Price { get; set; }

    public bool IsForSale { get; set; }

    public DateTime CreatedDate { get; set; } = DateTime.Now;
}