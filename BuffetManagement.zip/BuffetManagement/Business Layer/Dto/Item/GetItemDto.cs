﻿using Business_Layer.Dto.Category;
using Business_Layer.Dto.ItemPriceHistory;
using Business_Layer.Dto.Unit;
using Data_Access_Layer;

namespace Business_Layer.Dto.Item;

public class GetItemDto
{
    public int Id { get; set; }

    public string Name { get; set; } = null!;

    public string? Description { get; set; }

    public string? ImageUrl { get; set; }

    public int CategoryId { get; set; }
    public GetCategoryDto Category { get; set; } = null!;

    public int UnitId { get; set; }
    public GetUnitDto Unit { get; set; } = null!;

    public decimal? Cost { get; set; }
    public decimal? Price { get; set; }

    public bool IsForSale { get; set; }

    public DateTime CreatedDate { get; set; }
}