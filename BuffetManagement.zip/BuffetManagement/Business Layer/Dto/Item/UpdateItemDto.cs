﻿namespace Business_Layer.Dto.Item;

public class UpdateItemDto : CreateItemDto
{
    public int Id { get; set; }
}