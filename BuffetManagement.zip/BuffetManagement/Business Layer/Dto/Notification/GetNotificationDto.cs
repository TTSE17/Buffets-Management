﻿using Business_Layer.Dto.User;

namespace Business_Layer.Dto.Notification;

public class GetNotificationDto
{
    public int Id { get; set; }

    public string UserId { get; set; } = null!;

    public GetUserDto? User { get; set; }

    public string Title { get; set; } = null!;

    public string? Text { get; set; }

    public DateTime CreatedDateTime { get; set; } = DateTime.Now;

    public DateTime? ReadAtDateTime { get; set; }

    public bool IsRead => ReadAtDateTime.HasValue;
}