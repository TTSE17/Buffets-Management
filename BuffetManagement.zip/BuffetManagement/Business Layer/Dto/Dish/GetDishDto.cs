﻿namespace Business_Layer.Dto.Dish;

public class GetDishDto
{
    public int Id { get; set; }

    public string Name { get; set; } = null!;

    public string Recipe { get; set; } = null!;
    public string? Description { get; set; }
    public int PreparationTimeMinutes { get; set; }

    public string? ImageUrl { get; set; }

    public DateTime CreatedDate { get; set; } = DateTime.Now;

    public decimal Cost { get; set; }
    public decimal Price { get; set; }
}