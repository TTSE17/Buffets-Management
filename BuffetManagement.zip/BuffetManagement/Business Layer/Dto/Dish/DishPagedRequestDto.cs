﻿namespace Business_Layer.Dto.Dish;

public class DishPagedRequestDto
{
    public int? DishId { get; set; } = null;
    public string? Name { get; set; } = null;
    
    public DateTime? Date { get; set; } = null;
}