﻿namespace Business_Layer.Dto.Dish;

public class CreateUpdateDishDto : GetDishDto
{
}