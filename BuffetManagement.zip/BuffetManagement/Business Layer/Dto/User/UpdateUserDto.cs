﻿namespace Business_Layer.Dto.User;

public class UpdateUserDto : CreateUserDto
{
    public string Id { get; set; } = null!;

    public string? OldPassword { get; set; } = null!;
}