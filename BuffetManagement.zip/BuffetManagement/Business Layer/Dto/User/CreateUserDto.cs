﻿using System.ComponentModel.DataAnnotations;

namespace Business_Layer.Dto.User
{
    public class CreateUserDto
    {
        [Required] [EmailAddress] public string Email { get; set; } = null!;
        
        [Phone] public string PhoneNumber { get; set; } = null!;
        public string? Password { get; set; } = null!;
        [Required] public string UserName { get; set; } = null!;
        
        public string Address { get; set; } = null!;
    }
}