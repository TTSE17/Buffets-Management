﻿using System.ComponentModel.DataAnnotations;

namespace Business_Layer.Dto.User
{
    public class LoginDto
    {
        [Required(ErrorMessage = "Please Enter your UserName")]
        public string UserName { get; set; } = null!;

        [Required(ErrorMessage = "Please Enter your Password")]
        public string Password { get; set; } = null!;
        
        // [Required(ErrorMessage = "Please Enter your FCM")]
        public string? FCM { get; set; } = null!;
    }
}