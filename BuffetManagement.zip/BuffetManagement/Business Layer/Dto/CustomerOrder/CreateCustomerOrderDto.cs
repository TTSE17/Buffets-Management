﻿using System.ComponentModel.DataAnnotations;

namespace Business_Layer.Dto.CustomerOrder;

public class CreateCustomerOrderDto
{
    public string UserId { get; init; } = null!;
    public int BuffetId { get; init; }
    
    public decimal TotalCost { get; init; }
    
    public DateTime CreatedDate { get; set; } = DateTime.Now;

    [MinLength(1)] public Dictionary<int, int> Items { get; set; } = new();
}