﻿using Business_Layer.Dto.Item;
using Business_Layer.Dto.ItemPriceHistory;

namespace Business_Layer.Dto.CustomerOrder;

public class GetCustomerOrderDetailDto
{
    public int Id { get; set; }
    public int CustomerOrderId { get; set; }
    public int ItemId { get; set; }
    public GetItemDto Item { get; set; } = null!;
    public int Quantity { get; set; }
    public int ItemPriceHistoryId { get; set; }
    public GetItemPriceHistoryDto ItemPriceHistory { get; set; } = null!;
}