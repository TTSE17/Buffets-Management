﻿using Business_Layer.Dto.Buffet;
using Business_Layer.Dto.User;

namespace Business_Layer.Dto.CustomerOrder;

public class GetCustomerOrderDto
{
    public int Id { get; init; }
    public string UserId { get; init; } = null!;
    public GetUserDto User { get; init; } = null!;
    public int BuffetId { get; init; }
    public GetBuffetDto Buffet { get; init; } = null!;
    public decimal TotalCost { get; init; }
    public string Status { get; set; } = null!;
    public DateTime CreatedDate { get; set; }

    public List<GetCustomerOrderDetailDto> OrderDetails { get; set; } = [];


    public decimal TotalProfit { get; set; }
}