﻿using System.ComponentModel.DataAnnotations;

namespace Business_Layer.Dto.CustomerOrder;

public class SetStatusDto
{
    [Required] public int OrderId { get; set; }
    [Required] public string Status { get; set; } = null!;
    [Required] public int WorkerId { get; set; }
}