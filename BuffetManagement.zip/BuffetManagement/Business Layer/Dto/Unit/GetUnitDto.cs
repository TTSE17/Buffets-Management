﻿namespace Business_Layer.Dto.Unit
{
    public class GetUnitDto
    {
        public int Id { get; set; }

        public string UnitName { get; set; }

        public int Type { get; set; }
    }
}