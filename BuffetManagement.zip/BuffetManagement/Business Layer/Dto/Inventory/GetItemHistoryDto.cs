﻿using Business_Layer.Dto.Item;

namespace Business_Layer.Dto.Inventory;

public class GetItemHistoryDto
{
    public GetItemDto Item { get; set; } = null!;

    public List<GetInventoryDto> History { get; set; } = [];
}