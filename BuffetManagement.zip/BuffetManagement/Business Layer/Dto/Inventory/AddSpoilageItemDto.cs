﻿using System.ComponentModel.DataAnnotations;

namespace Business_Layer.Dto.Inventory;

public class AddSpoilageItemDto
{
    public int BuffetId { get; set; }

    public int ByWorkerId { get; set; }

    // public int ItemId { get; set; }
    // public decimal Amount { get; set; }

    [MinLength(1)] public Dictionary<int, int> Items { get; set; } = new();
}