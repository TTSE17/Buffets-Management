﻿namespace Business_Layer.Dto.Inventory;

public class GetSellingItemDto
{
    public string ItemName { get; set; } = null!;

    public decimal Revenue { get; set; }

    public decimal Sold { get; set; }
    
    
    public decimal Margin { get; set; }
    
}