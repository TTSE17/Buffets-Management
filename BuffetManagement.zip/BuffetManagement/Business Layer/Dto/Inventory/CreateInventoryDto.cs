﻿using AutoMapper.Configuration.Annotations;

namespace Business_Layer.Dto.Inventory;

public class CreateInventoryDto
{
    public int ItemId { get; set; }

    public int BuffetId { get; set; }

    public int ByWorkerId { get; set; }

    public decimal OpenQuantity { get; set; }
    
    public decimal ClosedQuantity { get; set; }

    [Ignore] public int? PriceHistoryId { get; set; }
}