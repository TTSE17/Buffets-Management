﻿using Business_Layer.Dto.Buffet;
using Business_Layer.Dto.Item;

namespace Business_Layer.Dto.Inventory;

public class GetInventoryDto
{
    public int Id { get; set; }

    public int ItemId { get; set; }
    public GetItemDto Item { get; set; } = null!;

    public int ItemPriceHistoryId { get; set; }

    public decimal? Cost { get; set; }
    public decimal? Price { get; set; }

    public int BuffetId { get; set; }
    public GetBuffetDto Buffet { get; set; } = null!;

    public int ByWorkerId { get; set; }
    public string WorkerName { get; set; } = null!;

    public decimal OpenQuantity { get; set; }
    public decimal ClosedQuantity { get; set; }

    public DateTime LastUpdate { get; set; }

    public decimal? SpoilageAmount { get; set; }
}