﻿namespace Business_Layer.Dto.Inventory;

public class UpdateInventoryDto : CreateInventoryDto
{
    public int Id { get; set; }
}