﻿namespace Business_Layer.Dto.Inventory;

public class InventoryPagedRequestDto
{
    // public string? Search { get; set; } = null;
    public int? CategoryId { get; set; } = null;
    public int? BuffetId { get; set; } = null;
    public DateTime? Date { get; set; } = null;

    public decimal? SpoilageAmount { get; set; } = null;

    public int PageNumber { get; set; } = 0;
}