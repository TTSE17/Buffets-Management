﻿namespace Business_Layer.Consts;

public abstract class Roles
{
    public const string Admin = "Admin";
    public const string Worker = "Worker";
    public const string Customer = "Customer";
}