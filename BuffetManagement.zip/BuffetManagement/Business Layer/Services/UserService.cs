﻿using System.ComponentModel.DataAnnotations;
using AutoMapper;
using Business_Layer.Consts;
using Business_Layer.Dto;
using Business_Layer.Dto.User;
using Business_Layer.Dto.Worker;
using Business_Layer.IServices;
using Data_Access_Layer;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;

namespace Business_Layer.Services
{
    public class UserService(
        UserManager<User> userManager,
        SignInManager<User> signInManager,
        IMapper mapper,
        AppDbContext context,
        TokenService tokenService) : IUserService
    {
        public async Task<Response<GetUserDto>> Register(CreateUserDto dto)
        {
            var response = new Response<GetUserDto>();

            try
            {
                var user = await userManager.FindByNameAsync(dto.UserName);

                if (user != null)
                {
                    response.Error = "UserName Is Already Exist";
                    return response;
                }

                var newUser = mapper.Map<User>(dto);
                newUser.UserType = UserType.User;

                var result = await userManager.CreateAsync(newUser, dto.Password!);

                if (!result.Succeeded)
                {
                    // Handle validation errors
                    var errors = string.Join(", ", result.Errors.Select(e => e.Description));
                    response.Error = $"Password validation failed: {errors}";

                    return response;
                }

                response.Success = true;

                response.Result = mapper.Map<GetUserDto>(newUser);

                await userManager.AddToRoleAsync(newUser, Roles.Customer);
            }
            catch (Exception e)
            {
                response.Error = e.Message;
            }

            return response;
        }

        public async Task<Response<AuthResponse>> Login(LoginDto dto, UserType type)
        {
            var response = new Response<AuthResponse>();

            var isValidEmail = new EmailAddressAttribute().IsValid(dto.UserName);

            User? user;

            if (isValidEmail)
            {
                user = await userManager.FindByEmailAsync(dto.UserName);
            }

            else
            {
                user = await userManager.FindByNameAsync(dto.UserName);
            }

            if (user == null || user.UserType != type)
            {
                response.Error = "Unable to Log In";

                return response;
            }

            var validPassword = await userManager.CheckPasswordAsync(user, dto.Password);

            if (validPassword == false)
            {
                response.Error = "Unable to Log In";

                return response;
            }

            var result = await signInManager.PasswordSignInAsync(user, dto.Password, false, false);

            if (!result.Succeeded)
            {
                response.Error = "Unable to Log In";

                return response;
            }

            if (dto.FCM != null)
            {
                user.FCM = dto.FCM;

                await context.SaveChangesAsync();
            }

            response.Success = true;

            response.Result = new AuthResponse
            {
                Token = await tokenService.CreateJwtToken(user),
                UserId = user.Id,
                User = mapper.Map<GetUserDto>(user)
            };

            return response;
        }

        public async Task<Response<GetUserDto>> Update(UpdateUserDto dto)
        {
            var response = new Response<GetUserDto>();

            try
            {
                var user = await userManager.FindByIdAsync(dto.Id);

                if (user == null)
                {
                    response.Error = "User Not Found";

                    return response;
                }

                var updatedUser = mapper.Map(dto, user);

                if (!string.IsNullOrEmpty(dto.Password) && !string.IsNullOrEmpty(dto.OldPassword))
                {
                    // await userManager.RemovePasswordAsync(user);
                    // user.PasswordHash = userManager.PasswordHasher.HashPassword(user, dto.Password);

                    var result = await userManager.ChangePasswordAsync(user, dto.OldPassword, dto.Password);

                    if (!result.Succeeded)
                    {
                        var errors = string.Join(", ", result.Errors.Select(e => e.Description));
                        response.Error = $"Password change failed: {errors}";
                        return response;
                    }
                }

                await userManager.UpdateNormalizedUserNameAsync(updatedUser);

                await userManager.UpdateNormalizedEmailAsync(updatedUser);

                await userManager.UpdateAsync(updatedUser);

                response.Result = mapper.Map<GetUserDto>(updatedUser);
            }
            catch (Exception e)
            {
                response.Error = e.Message + "\n";
            }

            response.Success = true;

            return response;
        }

        public async Task Logout()
        {
            await signInManager.SignOutAsync();
        }
    }
}