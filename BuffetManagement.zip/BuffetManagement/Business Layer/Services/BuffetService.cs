﻿using System.Diagnostics.CodeAnalysis;
using System.Linq.Expressions;
using AutoMapper;
using Business_Layer.Dto;
using Business_Layer.Dto.Buffet;
using Business_Layer.IServices;
using Data_Access_Layer;
using Microsoft.EntityFrameworkCore;

namespace Business_Layer.Services;

public class BuffetService(IMapper mapper, AppDbContext context) : IBuffetService
{
    public async Task<Response<List<GetBuffetDto>>> GetAll(Expression<Func<Buffet, bool>>? criteria = null)
    {
        var response = new Response<List<GetBuffetDto>>();

        var query = context.Buffets.AsNoTracking();

        if (criteria != null)
        {
            query = query.Where(criteria);
        }

        var buffets = await query.ToListAsync();

        response.Success = true;
        response.Result = mapper.Map<List<GetBuffetDto>>(buffets);

        return response;
    }

    [SuppressMessage("ReSharper.DPA", "DPA0009: High execution time of DB command", MessageId = "time: 1187ms")]
    public async Task<Response<List<object>>> GetAllOverview(Expression<Func<Buffet, bool>>? criteria = null)
    {
        var response = new Response<List<object>>();

        var query = context.Buffets.AsNoTracking();

        if (criteria != null)
        {
            query = query.Where(criteria);
        }

        var buffets = await query.ToListAsync();

        var buffetDtos = mapper.Map<List<GetBuffetDto>>(buffets);

        var objects = new List<object>();

        foreach (var buffet in buffetDtos)
        {
            var buffetId = buffet.Id;

            var ordersToday = await context.CustomerOrders
                .Where(o => o.BuffetId == buffetId)
                .Where(o => o.CreatedDate >= DateTime.Now.Date)
                .OrderBy(o => o.CreatedDate)
                .CountAsync();

            var totalWorkers = await context.Workers.Where(w => w.BuffetId == buffetId).CountAsync();

            objects.Add(new { buffet, ordersToday, totalWorkers });
        }

        response.Result = objects;

        response.Success = true;

        return response;
    }

    public async Task<Response<GetBuffetDto>> Add(CreateBuffetDto dto)
    {
        var response = new Response<GetBuffetDto>();

        try
        {
            var buffetToAdd = mapper.Map<Buffet>(dto);

            var buffet = await context.Buffets.AddAsync(buffetToAdd);

            await context.SaveChangesAsync();

            response.Success = true;

            response.Result = mapper.Map<GetBuffetDto>(buffet.Entity);
        }
        catch (Exception e)
        {
            response.Error = e.Message;
        }

        return response;
    }

    public async Task<Response<GetBuffetDto>> Update(UpdateBuffetDto dto)
    {
        var response = new Response<GetBuffetDto>();

        try
        {
            var buffetToUpdate = await context.Buffets.FindAsync(dto.Id);

            if (buffetToUpdate == null)
            {
                response.Error = "Buffet could not be found";

                return response;
            }

            var buffet = mapper.Map(dto, buffetToUpdate);

            await context.SaveChangesAsync();

            response.Success = true;

            response.Result = mapper.Map<GetBuffetDto>(buffet);
        }
        catch (Exception e)
        {
            response.Error = e.Message;
        }

        return response;
    }

    public async Task<Response<bool>> Delete(int id)
    {
        var response = new Response<bool>();

        try
        {
            var buffetToDelete = await context.Buffets.FindAsync(id);

            if (buffetToDelete == null)
                response.Error = "Buffet could not be found";
            else
            {
                context.Buffets.Remove(buffetToDelete);

                await context.SaveChangesAsync();

                response.Success = true;
            }
        }
        catch (Exception e)
        {
            response.Error = e.Message;
        }

        response.Success = true;

        response.Result = true;

        return response;
    }

    public async Task<Response<GetBuffetDto>> AddValue(int buffetId, decimal value)
    {
        var response = new Response<GetBuffetDto>();

        try
        {
            var box = await context.Buffets.Where(b => b.Id == buffetId).FirstOrDefaultAsync();

            if (box == null)
            {
                response.Error = $"Buffet {buffetId} does not exist";
                return response;
            }

            if (box.BoxValue + value < 0)
            {
                response.Error = "Box must have a value greater than zero";

                return response;
            }

            box.BoxValue += value;

            await context.SaveChangesAsync();

            response.Result = mapper.Map<GetBuffetDto>(box);

            response.Success = true;
        }
        catch (Exception e)
        {
            response.Error = e.Message;
        }

        return response;
    }
}