﻿using System.Linq.Expressions;
using AutoMapper;
using Business_Layer.Dto;
using Business_Layer.Dto.CustomerOrder;
using Business_Layer.Dto.Inventory;
using Business_Layer.IServices;
using Data_Access_Layer;
using Microsoft.EntityFrameworkCore;

namespace Business_Layer.Services;

public class CustomerOrderService(
    IMapper mapper,
    AppDbContext context,
    IItemService itemService,
    IInventoryService inventoryService,
    IFirebaseService firebaseService) : ICustomerOrderService
{
    public async Task<Response<GetCustomerOrderDto>> Add(CreateCustomerOrderDto dto)
    {
        var response = new Response<GetCustomerOrderDto>();

        await using var transaction = await context.Database.BeginTransactionAsync();

        try
        {
            var orderToAdd = mapper.Map<CustomerOrder>(dto);
            orderToAdd.CreatedDate = DateTime.Now;
            orderToAdd.Status = OrderStatus.Pending;

            var order = (await context.CustomerOrders.AddAsync(orderToAdd)).Entity;

            await context.SaveChangesAsync();

            var orderDetails = new List<CustomerOrderDetail>();

            var itemsDto = dto.Items;

            foreach (var (itemId, quantity) in itemsDto)
            {
                var totalQuantity = await inventoryService.CheckQuantity(itemId, dto.BuffetId);

                if (totalQuantity == null || totalQuantity.Value < quantity)
                {
                    response.Error = $"Item {itemId} does not have enough quantity";

                    return response;
                }

                var itemPriceHistory = await itemService.GetLastItemPriceHistory(itemId, dto.BuffetId);

                if (itemPriceHistory == null)
                    throw new Exception("Item not Pricing");

                var orderDetail = new CustomerOrderDetail
                {
                    CustomerOrderId = order.Id,
                    ItemId = itemId,
                    Quantity = quantity,
                    ItemPriceHistoryId = itemPriceHistory.Id
                };

                await context.CustomerOrderDetails.AddAsync(orderDetail);

                orderDetails.Add(orderDetail);
            }

            var orderDto = mapper.Map<GetCustomerOrderDto>(order);

            orderDto.OrderDetails = mapper.Map<List<GetCustomerOrderDetailDto>>(orderDetails);

            response.Result = orderDto;

            response.Success = true;

            await context.SaveChangesAsync();

            await transaction.CommitAsync();

            await firebaseService.NotifyWorkers("New Customer Order", "", dto.BuffetId);
        }
        catch (Exception e)
        {
            await transaction.RollbackAsync();

            response.Error = e.Message;
        }

        return response;
    }

    public async Task<Response<List<GetCustomerOrderDto>>> GetAll(CustomerOrderPagedRequestDto dto,
        Expression<Func<CustomerOrder, bool>>? criteria = null)
    {
        var response = new Response<List<GetCustomerOrderDto>>();

        const int pageSize = 3;

        var pageNumber = dto.PageNumber;

        var query = context.CustomerOrders.AsNoTracking().AsQueryable();

        if (criteria != null)
        {
            query = query.Where(criteria);
        }

        if (pageNumber > 0)
        {
            response.TotalPages = (int)Math.Ceiling((double)query.Count() / pageSize);

            query = query.Skip((pageNumber - 1) * pageSize).Take(pageSize);
        }

        query = query
            .Include(o => o.User)
            .Include(o => o.Buffet)
            .OrderByDescending(o => o.Id);

        var orders = await query.ToListAsync();

        if (orders.Count == 0)
        {
            response.Result = [];

            return response;
        }

        var result = mapper.Map<List<GetCustomerOrderDto>>(orders);

        response.Result = result;

        response.Success = true;

        return response;
    }

    public async Task<Response<GetCustomerOrderDto?>> GetDetails(int orderId)
    {
        var response = new Response<GetCustomerOrderDto?>();

        var order = await context.CustomerOrders.AsNoTracking()
            .Where(o => o.Id == orderId)
            .Include(o => o.User)
            .Include(o => o.Buffet)
            .Include(o => o.OrderDetails)
            .ThenInclude(i => i.Item)
            .FirstOrDefaultAsync();

        if (order is null)
        {
            response.Result = null;

            return response;
        }

        var result = mapper.Map<GetCustomerOrderDto>(order);

        decimal totalProfit = 0;
        foreach (var orderDetail in result.OrderDetails)
        {
            var priceHistory = await itemService.GetPriceHistory(orderDetail.ItemPriceHistoryId);

            var cost = priceHistory?.Cost;
            var price = priceHistory?.Price;

            orderDetail.Item.Cost = cost;
            orderDetail.Item.Price = price;

            totalProfit += ((price ?? 1) - (cost ?? 1)) * orderDetail.Quantity;
        }

        result.TotalProfit = totalProfit;

        response.Result = result;

        response.Success = true;

        return response;
    }

    public async Task<Response<GetCustomerOrderDto>> SetStatus(int orderId, int workerId, OrderStatus status)
    {
        var response = new Response<GetCustomerOrderDto>();

        try
        {
            var order = await context.CustomerOrders.FindAsync(orderId);

            if (order == null)
            {
                response.Error = "Order not found";
                return response;
            }

            var orderStatus = order.Status;

            if (orderStatus == status)
            {
                response.Result = mapper.Map<GetCustomerOrderDto>(order);

                response.Success = true;

                return response;
            }

            if (orderStatus is OrderStatus.Completed or OrderStatus.Canceled)
            {
                response.Error = "You cannot change order status";

                return response;
            }

            if (status == OrderStatus.Completed)
            {
                var isUpdated = await UpdateQuantityInInventory(order, workerId);

                if (!isUpdated.Success)
                {
                    response.Error = isUpdated.Error;

                    return response;
                }
            }

            order.Status = status;

            await context.SaveChangesAsync();

            await firebaseService.NotifyUser("Update Order Status", status.ToString(), order.UserId);

            response.Result = mapper.Map<GetCustomerOrderDto>(order);

            response.Success = true;
        }
        catch (Exception e)
        {
            response.Error = e.Message;
        }

        return response;
    }

    private async Task<Response<bool?>> UpdateQuantityInInventory(CustomerOrder order, int workerId)
    {
        var response = new Response<bool?>();

        await using var transaction = await context.Database.BeginTransactionAsync();

        try
        {
            var orderId = order.Id;

            var buffetId = order.BuffetId;

            var orderDetails = await context.CustomerOrderDetails.AsNoTracking()
                .Where(o => o.CustomerOrderId == orderId).ToListAsync();

            if (orderDetails.Count == 0)
            {
                response.Error = "There are no items in order";

                return response;
            }

            foreach (var orderDetail in orderDetails)
            {
                var itemId = orderDetail.ItemId;

                // var isSandwich = await itemService.IsSandwich(itemId);
                // if (isSandwich) continue;

                var newQuantity = await inventoryService.CalculateNewQuantity(
                    itemId, buffetId, orderDetail.Quantity);

                if (newQuantity == null)
                    throw new Exception($"Ingredient {itemId} does not have enough quantity");

                var updateInventoryDto = new CreateInventoryDto
                {
                    ItemId = itemId,
                    ByWorkerId = workerId,
                    BuffetId = buffetId,
                    ClosedQuantity = newQuantity.Value.ClosedQuantity,
                    OpenQuantity = newQuantity.Value.OpenQuantity,
                    PriceHistoryId = orderDetail.ItemPriceHistoryId
                };

                await inventoryService.Add(updateInventoryDto);

                await context.SaveChangesAsync();
            }

            await transaction.CommitAsync();
        }
        catch (Exception e)
        {
            await transaction.RollbackAsync();

            response.Error = e.Message;

            return response;
        }

        response.Success = true;

        return response;
    }
}