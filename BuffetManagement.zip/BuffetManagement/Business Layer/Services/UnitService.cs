﻿using AutoMapper;
using Business_Layer.Dto;
using Business_Layer.Dto.Unit;
using Business_Layer.IServices;
using Data_Access_Layer;
using Microsoft.EntityFrameworkCore;

namespace Business_Layer.Services
{
    public class UnitService(IMapper mapper, AppDbContext context) : IUnitService
    {
        public async Task<Response<List<GetUnitDto>>> GetAll()
        {
            var response = new Response<List<GetUnitDto>>();

            var buffets = await context.Units.ToListAsync();

            response.Success = true;
            response.Result = mapper.Map<List<GetUnitDto>>(buffets);

            return response;
        }
    }
}