﻿using AutoMapper;
using Business_Layer.Dto;
using Business_Layer.Dto.Component;
using Business_Layer.Dto.Inventory;
using Business_Layer.Dto.Item;
using Business_Layer.IServices;
using Data_Access_Layer;
using Microsoft.EntityFrameworkCore;

namespace Business_Layer.Services;

public class ComponentService(
    IMapper mapper,
    AppDbContext context,
    IItemService itemService,
    IInventoryService inventoryService,
    IFirebaseService firebaseService) : IComponentService
{
    public async Task<Response<GetComponentDto>> Create(CreateComponentDto dto, ComponentType type)
    {
        var response = new Response<GetComponentDto>();

        await using var transaction = await context.Database.BeginTransactionAsync();

        try
        {
            var component = mapper.Map<Item>(dto.Component);

            component.CategoryId = (await context.Categories.FirstAsync(c => c.Name == type.ToString())).Id;
            component.UnitId = (int)UnitName.Piece;
            component.IsForSale = true;
            component.CreatedDate = DateTime.Now;

            component = (await context.Items.AddAsync(component)).Entity;
            await context.SaveChangesAsync();

            var ingredientIds = dto.Ingredients;

            var ingredients = new List<Item>();

            foreach (var ingredientId in ingredientIds)
            {
                var ingredient = await context.Items.FirstOrDefaultAsync(i => i.Id == ingredientId);

                if (ingredient == null)
                    throw new Exception($"Ingredient {ingredientId} not found");

                ingredients.Add(ingredient);

                var componentIngredient = new ComponentIngredients
                {
                    ComponentId = component.Id,
                    IngredientId = ingredientId,
                };

                await context.ComponentIngredients.AddAsync(componentIngredient);
            }

            await context.SaveChangesAsync();
            await transaction.CommitAsync();

            response.Result = new GetComponentDto
            {
                Component = mapper.Map<GetItemDto>(component),
                Ingredients = mapper.Map<List<GetItemDto>>(ingredients)
            };

            response.Success = true;

            await firebaseService.NotifyWorkers("New Component Added", dto.Component.Name);
        }

        catch (Exception ex)
        {
            await transaction.RollbackAsync();
            response.Error = $"An error occurred: {ex.Message}";
        }

        return response;
    }

    public async Task<Response<GetComponentDto>> Update(int componentId, CreateComponentDto dto)
    {
        var response = new Response<GetComponentDto>();

        await using var transaction = await context.Database.BeginTransactionAsync();

        try
        {
            var component = await context.Items.FirstOrDefaultAsync(i => i.Id == componentId);

            if (component == null)
            {
                response.Error = $"Component {componentId} not found";
                return response;
            }

            mapper.Map(dto.Component, component);

            component = context.Items.Update(component).Entity;
            await context.SaveChangesAsync();

            var ingredientIds = dto.Ingredients;

            var currentIngredients = await context.ComponentIngredients
                .Where(ci => ci.ComponentId == componentId)
                .Include(i => i.Ingredient)
                .ToListAsync();

            var ingredientsToRemove = currentIngredients
                .Where(i => !ingredientIds.Contains(i.IngredientId))
                .ToList();

            context.ComponentIngredients.RemoveRange(ingredientsToRemove);

            // var ingredientsIdsToAdd = ingredientIds
            //     .Where(i => currentIngredients.Any(ci => ci.IngredientId != i))
            //     .AsQueryable();

            var ingredients = new List<Item>();

            foreach (var ingredientId in ingredientIds)
            {
                var isExistIngredient = currentIngredients
                    .FirstOrDefault(i => i.IngredientId == ingredientId);

                if (isExistIngredient != null)
                {
                    ingredients.Add(isExistIngredient.Ingredient);

                    continue;
                }

                var ingredient = await context.Items.FirstOrDefaultAsync(i => i.Id == ingredientId);

                if (ingredient == null)
                    throw new Exception($"Ingredient {ingredientId} not found");

                ingredients.Add(ingredient);

                var componentIngredient = new ComponentIngredients
                {
                    ComponentId = component.Id,
                    IngredientId = ingredientId,
                };

                await context.ComponentIngredients.AddAsync(componentIngredient);
            }

            await context.SaveChangesAsync();
            await transaction.CommitAsync();

            response.Result = new GetComponentDto
            {
                Component = mapper.Map<GetItemDto>(component),
                Ingredients = mapper.Map<List<GetItemDto>>(ingredients)
            };

            response.Success = true;
        }

        catch (Exception ex)
        {
            await transaction.RollbackAsync();
            response.Error = $"An error occurred: {ex.Message}";
        }

        return response;
    }

    public async Task<Response<object>> CalculateCost(CalculateCostComponentDto dto)
    {
        var response = new Response<object>();

        var totalCost = decimal.Zero;

        var buffetId = dto.BuffetId;

        foreach (var (ingredientId, amount) in dto.Ingredients)
        {
            var totalQuantity = await inventoryService.CheckQuantity(ingredientId, buffetId);

            if (totalQuantity == null || totalQuantity.Value < amount)
            {
                response.Error = $"Ingredient {ingredientId} does not have enough quantity";

                return response;
            }

            var ingredientPriceHistory = await itemService.GetLastItemPriceHistory(ingredientId, buffetId);

            if (ingredientPriceHistory == null)
            {
                response.Error = $"Ingredient {ingredientId} not found";

                return response;
            }

            var ingredientCost = ingredientPriceHistory.Cost;

            totalCost += ingredientCost!.Value * amount;
        }


        var costForOne = totalCost / dto.Count;

        response.Result = new { TotalCost = totalCost, costForOne };

        response.Success = true;

        return response;
    }

    public async Task<Response<object>> Add(AddComponentDto dto)
    {
        var response = new Response<object>();

        await using var transaction = await context.Database.BeginTransactionAsync();

        try
        {
            var componentId = dto.ComponentId;
            var workerId = dto.WorkerId;
            var buffetId = dto.BuffetId;
            var cost = dto.Cost;
            var price = dto.Price;
            var count = dto.Count;

            var priceHistoryToAdd = new ItemPriceHistory
            {
                ItemId = componentId,
                Cost = cost,
                Price = price,
                CreatedDate = DateTime.Now,
                BuffetId = buffetId
            };

            await context.ItemPriceHistory.AddAsync(priceHistoryToAdd);
            await context.SaveChangesAsync();

            var createInventoryDto = new CreateInventoryDto
            {
                ItemId = componentId,
                ByWorkerId = workerId,
                BuffetId = buffetId,
                ClosedQuantity = 0,
                OpenQuantity = count
            };

            var currentInventory = await context.Inventories.Where(i =>
                    i.ItemId == componentId &&
                    i.BuffetId == buffetId
                // && i.LastUpdate.Date == DateTime.Now.Date
            ).FirstOrDefaultAsync();

            if (currentInventory != null)
            {
                createInventoryDto.OpenQuantity += currentInventory.OpenQuantity;
            }

            var component = await inventoryService.Add(createInventoryDto);

            var ingredientsDto = dto.Ingredients;

            foreach (var (ingredientId, amount) in ingredientsDto)
            {
                var newQuantity = await inventoryService.CalculateNewQuantity(ingredientId, buffetId, amount);

                if (newQuantity == null)
                    throw new Exception($"Ingredient {ingredientId} does not have enough quantity");

                var updateInventoryDto = new CreateInventoryDto
                {
                    ItemId = ingredientId,
                    ByWorkerId = workerId,
                    BuffetId = buffetId,
                    ClosedQuantity = newQuantity.Value.ClosedQuantity,
                    OpenQuantity = newQuantity.Value.OpenQuantity
                };

                await inventoryService.Add(updateInventoryDto);

                var itemPriceHistory = await itemService.GetLastItemPriceHistory(ingredientId, buffetId);

                var costItem = itemPriceHistory?.Cost;

                var buffetComponentIngredient = new BuffetComponentIngredients
                {
                    ComponentId = componentId,
                    IngredientId = ingredientId,
                    BuffetId = buffetId,
                    Cost = costItem!.Value,
                    Amount = amount,
                };

                await context.BuffetComponentIngredients.AddAsync(buffetComponentIngredient);

                await context.SaveChangesAsync();
            }

            await transaction.CommitAsync();

            response.Result = component.Result;

            response.Success = true;
        }
        catch (Exception ex)
        {
            await transaction.RollbackAsync();
            response.Error = $"An error occurred: {ex.Message}";
        }

        return response;
    }

    public async Task<Response<GetComponentDto>> GetComponentDetails(int componentId)
    {
        var response = new Response<GetComponentDto>();

        var component = await context.Items.AsNoTracking().Where(i => i.Id == componentId)
            .Include(i => i.Category)
            .Include(i => i.Unit)
            .FirstOrDefaultAsync();

        if (component == null)
        {
            response.Error = $"Component {componentId} does not exist";
            return response;
        }

        var componentIngredients = await context.ComponentIngredients.AsNoTracking()
            .Where(c => c.ComponentId == componentId)
            .Include(c => c.Ingredient)
            .Select(c => c.Ingredient)
            .ToListAsync();

        if (componentIngredients.Count == 0)
        {
            response.Error = $"Component {componentId} does not have any ingredients";

            return response;
        }

        var componentDto = new GetComponentDto
        {
            Component = mapper.Map<GetItemDto>(component),
            Ingredients = mapper.Map<List<GetItemDto>>(componentIngredients)
        };

        foreach (var i in componentDto.Ingredients)
        {
            var priceInfo = await itemService.GetLastItemPriceHistory(i.Id, null);

            if (priceInfo == null) continue;
            i.Price = priceInfo.Price;
            i.Cost = priceInfo.Cost;
        }

        response.Result = componentDto;

        response.Success = true;

        return response;
    }
}