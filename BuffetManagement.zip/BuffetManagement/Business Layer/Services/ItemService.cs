﻿using System.Linq.Expressions;
using AutoMapper;
using Business_Layer.Dto;
using Business_Layer.Dto.Component;
using Business_Layer.Dto.Item;
using Business_Layer.Dto.ItemPriceHistory;
using Business_Layer.IServices;
using Data_Access_Layer;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;

namespace Business_Layer.Services;

public class ItemService(
    IMapper mapper,
    AppDbContext context,
    IServiceProvider serviceProvider,
    IFirebaseService firebaseService) : IItemService
{
    private IComponentService _componentService = null!;

    private void SomeMethod()
    {
        _componentService = serviceProvider.GetRequiredService<IComponentService>();
    }

    public async Task<GetItemPriceHistoryDto?> GetLastItemPriceHistory(int itemId, int? buffetId)
    {
        var priceHistory = await context.ItemPriceHistory
            .Where(p => p.ItemId == itemId)
            .Where(p => p.BuffetId == buffetId || p.BuffetId == null /* Mean Is Global */)
            .OrderByDescending(p => p.Id)
            .FirstOrDefaultAsync();

        return priceHistory == null ? null : mapper.Map<GetItemPriceHistoryDto>(priceHistory);
    }

    public async Task<GetItemPriceHistoryDto?> GetPriceHistory(int priceHistoryId)
    {
        var priceHistory = await context.ItemPriceHistory.AsNoTracking()
            .FirstOrDefaultAsync(p => p.Id == priceHistoryId);

        return priceHistory == null ? null : mapper.Map<GetItemPriceHistoryDto>(priceHistory);
    }

    public async Task<bool> IsSandwich(int itemId)
    {
        var item = await context.Items.AsNoTracking().Where(i => i.Id == itemId)
            .Include(i => i.Category).FirstOrDefaultAsync();

        return item is { CategoryId: 4 } && string.Equals(item.Category.Name, "Sandwich",
            StringComparison.InvariantCultureIgnoreCase);
    }

    public async Task<Response<List<GetItemDto>>> GetAll(ItemPagedRequestDto dto,
        Expression<Func<Item, bool>>? criteria = null)
    {
        var response = new Response<List<GetItemDto>>();

        var pageNumber = dto.PageNumber;

        const int pageSize = 3;

        var query = context.Items.AsNoTracking().AsQueryable();

        if (criteria != null)
        {
            query = query.Where(criteria);
        }

        if (pageNumber > 0)
        {
            response.TotalPages = (int)Math.Ceiling((double)query.Count() / pageSize);

            query = query.Skip((pageNumber - 1) * pageSize).Take(pageSize);
        }

        if (!query.Any())
        {
            response.Success = true;

            response.Result = [];

            return response;
        }

        query = query
            .Include(i => i.Category)
            .Include(i => i.Unit);

        var items = await query.ToListAsync();

        response.Success = true;

        var result = mapper.Map<List<GetItemDto>>(items);

        foreach (var itemDto in result)
        {
            if (itemDto.Category.Name == "Sandwich") continue;

            var priceInfo = await GetLastItemPriceHistory(itemDto.Id, null); // Not For Sandwich

            if (priceInfo == null) continue;

            itemDto.Price = priceInfo.Price;
            itemDto.Cost = priceInfo.Cost;
        }

        response.Result = result;

        return response;
    }

    public async Task<Response<GetComponentDto>> GetItemDetails(int id)
    {
        SomeMethod();

        var response = new Response<GetComponentDto>();

        if (await IsSandwich(id))
        {
            var componentResponse = await _componentService.GetComponentDetails(id);

            if (componentResponse.Success)
            {
                response.Result = componentResponse.Result;

                response.Success = true;

                return response;
            }

            response.Error = componentResponse.Error;

            return response;
        }

        var query = context.Items.AsNoTracking().Where(i => i.Id == id);

        if (!query.Any())
        {
            response.Error = $"item {id} does not exist";
            return response;
        }

        query = query
            .Include(i => i.Category)
            .Include(i => i.Unit);

        var items = await query.FirstAsync();

        var result = mapper.Map<GetItemDto>(items);

        var priceInfo = await GetLastItemPriceHistory(result.Id, null);

        if (priceInfo != null)
        {
            result.Price = priceInfo.Price;
            result.Cost = priceInfo.Cost;
        }

        response.Result = new GetComponentDto
        {
            Component = result
        };

        response.Success = true;

        return response;
    }

    public async Task<Response<List<GetItemDto>>> GetAllSandwiches()
    {
        var response = new Response<List<GetItemDto>>();


        const int pageSize = 3;

        var query = context.Items.AsNoTracking().AsQueryable().Where(i =>
            i.Category.Name == "Sandwich");

        if (!query.Any())
        {
            response.Success = true;

            response.Result = [];

            return response;
        }

        var items = await query.ToListAsync();

        response.Success = true;

        var result = mapper.Map<List<GetItemDto>>(items);

        response.Result = result;

        return response;
    }

    public async Task<Response<GetItemDto>> Add(CreateItemDto dto)
    {
        var response = new Response<GetItemDto>();

        try
        {
            var itemToAdd = mapper.Map<Item>(dto);

            var item = await context.Items.AddAsync(itemToAdd);

            await context.SaveChangesAsync();

            var priceHistory = new ItemPriceHistory();

            if (dto.Price != null || dto.Cost != null)
            {
                priceHistory = new ItemPriceHistory
                {
                    ItemId = item.Entity.Id,
                    Cost = dto.Cost,
                    Price = dto.Price == 0 ? null : dto.Price,
                    CreatedDate = DateTime.Now,
                };

                priceHistory = (await context.ItemPriceHistory.AddAsync(priceHistory)).Entity;

                await context.SaveChangesAsync();
            }

            var result = mapper.Map<GetItemDto>(item.Entity);

            result.Price = priceHistory.Price;
            result.Cost = priceHistory.Cost;

            response.Result = result;

            response.Success = true;

            await firebaseService.NotifyWorkers("New Item Added", dto.Name);
        }
        catch (Exception e)
        {
            response.Error = e.Message;
        }

        return response;
    }

    public async Task<Response<GetItemDto>> Update(UpdateItemDto dto)
    {
        var response = new Response<GetItemDto>();

        try
        {
            var itemToUpdate = await context.Items.FindAsync(dto.Id);

            if (itemToUpdate == null)
            {
                response.Error = "Item Not Found";

                return response;
            }

            itemToUpdate = mapper.Map(dto, itemToUpdate);

            var priceHistoryDto = await GetLastItemPriceHistory(dto.Id, null); // Not For Sandwich

            if ((priceHistoryDto!.Price != dto.Price && dto.Price != 0) || priceHistoryDto.Cost != dto.Cost)
            {
                var priceHistoryToAdd = new ItemPriceHistory
                {
                    ItemId = itemToUpdate.Id,
                    Cost = dto.Cost,
                    Price = dto.Price,
                    CreatedDate = DateTime.Now,
                };

                var priceHistory = (await context.ItemPriceHistory.AddAsync(priceHistoryToAdd)).Entity;

                priceHistoryDto.Cost = priceHistory.Cost;
                priceHistoryDto.Price = priceHistoryDto.Price;
            }

            await context.SaveChangesAsync();

            response.Success = true;

            var result = mapper.Map<GetItemDto>(itemToUpdate);

            result.Price = priceHistoryDto.Price;
            result.Cost = priceHistoryDto.Cost;

            response.Result = result;
        }
        catch (Exception e)
        {
            response.Error = e.Message;
        }

        return response;
    }

    public async Task<Response<bool>> Delete(int id)
    {
        var response = new Response<bool>();

        try
        {
            var item = await context.Items.FindAsync(id);

            if (item == null)
                response.Error = "Item Not Found";
            else
            {
                context.Items.Remove(item);

                await context.ComponentIngredients.Where(c => c.ComponentId == item.Id).ExecuteDeleteAsync();

                await context.SaveChangesAsync();

                response.Result = true;

                response.Success = true;
            }
        }
        catch (Exception e)
        {
            response.Error = e.Message;
        }

        return response;
    }
}