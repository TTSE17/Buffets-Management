﻿using Business_Layer.Dto;
using Business_Layer.Dto.Notification;
using Business_Layer.IServices;
using Data_Access_Layer;
using Microsoft.AspNetCore.Hosting;
using Microsoft.EntityFrameworkCore;

namespace Business_Layer.Services;

using FirebaseAdmin;
using FirebaseAdmin.Messaging;
using Google.Apis.Auth.OAuth2;

public class FirebaseService : IFirebaseService
{
    private readonly AppDbContext _context;

    private readonly INotificationService _notificationService;

    public FirebaseService(AppDbContext context, IWebHostEnvironment env, INotificationService notificationService)
    {
        _context = context;
        _notificationService = notificationService;

        if (FirebaseApp.DefaultInstance == null)
        {
            var basePath = env.ContentRootPath;
            var jsonPath = Path.Combine(basePath, "abd-alhamed-firebase-adminsdk-fbsvc-42f7fc9ab0.json");

            FirebaseApp.Create(new AppOptions
            {
                Credential = GoogleCredential.FromFile(jsonPath)
            });
        }
    }

    public async Task<Response<string>> SendNotificationAsync(string deviceToken, string title, string body)
    {
        var response = new Response<string>();

        var message = new Message
        {
            Token = deviceToken,

            Notification = new Notification
            {
                Title = title,
                Body = body
            }
        };

        var messageId = await FirebaseMessaging.DefaultInstance.SendAsync(message);

        response.Result = messageId;

        response.Success = true;

        return response;
    }

    public async Task NotifyAdmin(string title, string body)
    {
        var admins = await _context.Users.AsNoTracking()
            .Where(u => u.Type == UserType.Admin.ToString())
            .ToListAsync();

        foreach (var admin in admins)
        {
            if (admin.FCM == null) continue;

            await SendNotificationAsync(admin.FCM, title, body);

            var notificationDto = new GetNotificationDto
            {
                Title = title,
                Text = body,
                UserId = admin.Id,
                CreatedDateTime = DateTime.Now
            };

            await _notificationService.Add(notificationDto);
        }
    }

    public async Task NotifyUser(string title, string body, string userId)
    {
        var user = await _context.Users.AsNoTracking()
            .Where(u => u.Id == userId)
            .FirstOrDefaultAsync();

        if (user?.FCM != null)
        {
            await SendNotificationAsync(user.FCM, title, body);

            var notificationDto = new GetNotificationDto
            {
                Title = title,
                Text = body,
                UserId = user.Id,
                CreatedDateTime = DateTime.Now
            };

            await _notificationService.Add(notificationDto);
        }
    }

    public async Task NotifyWorkers(string title, string body, int? buffetId = null)
    {
        var workers = await _context.Workers.AsNoTracking()
            .Where(w => w.BuffetId == buffetId || !buffetId.HasValue)
            .Include(w => w.User)
            .ToListAsync();

        foreach (var worker in workers)
        {
            if (worker.User.FCM == null) continue;

            await SendNotificationAsync(worker.User.FCM, title, body);

            var notificationDto = new GetNotificationDto
            {
                Title = title,
                Text = body,
                UserId = worker.UserId,
                CreatedDateTime = DateTime.Now
            };

            await _notificationService.Add(notificationDto);
        }
    }
}