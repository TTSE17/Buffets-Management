﻿using System.Linq.Expressions;
using AutoMapper;
using Business_Layer.Consts;
using Business_Layer.Dto;
using Business_Layer.Dto.User;
using Business_Layer.Dto.Worker;
using Business_Layer.IServices;
using Data_Access_Layer;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;

namespace Business_Layer.Services
{
    public class WorkerService(
        UserManager<User> userManager,
        IMapper mapper,
        AppDbContext context,
        IUserService userService) : IWorkerService
    {
        public async Task<GetWorkerDto?> GetWorkerDto(int workerId)
        {
            var worker = await context.Workers.AsNoTracking()
                .Include(w => w.User)
                .FirstOrDefaultAsync(w => w.Id == workerId);


            return worker == null ? null : mapper.Map<GetWorkerDto>(worker);
            ;
        }

        public async Task<Response<GetWorkerDto>> Register(CreateWorkerDto dto)
        {
            var response = new Response<GetWorkerDto>();

            try
            {
                var user = await userManager.FindByNameAsync(dto.User.UserName);

                if (user != null)
                {
                    response.Error = "UserName Is Already Exist";
                    return response;
                }

                var newUser = mapper.Map<User>(dto.User);
                newUser.UserType = UserType.Worker;

                var result = await userManager.CreateAsync(newUser, dto.User.Password!);

                if (result.Succeeded)
                {
                    var newWorker = mapper.Map<Worker>(dto);
                    newWorker.UserId = newUser.Id;
                    newWorker.User = null!;

                    context.Workers.Add(newWorker);

                    await context.SaveChangesAsync();

                    var newWorkerDto = mapper.Map<GetWorkerDto>(newWorker);
                    newWorkerDto.BuffetName = (await context.Buffets.FindAsync(newWorker.BuffetId))!.Name;

                    await userManager.AddToRoleAsync(newUser, Roles.Worker);

                    response.Success = true;
                    response.Result = newWorkerDto;

                    return response;
                }

                foreach (var error in result.Errors)
                {
                    response.Error += error.Description + "\n";
                }
            }
            catch (Exception e)
            {
                response.Error = e.Message + "\n";
            }

            return response;
        }

        public async Task<Response<WorkerAuthResponse>> Login(LoginDto dto)
        {
            var response = new Response<WorkerAuthResponse>();

            var userLoginResponse = await userService.Login(dto, UserType.Worker);

            if (!userLoginResponse.Success)
            {
                response.Error = userLoginResponse.Error;
                return response;
            }

            var worker = await context.Workers.AsNoTracking()
                .FirstOrDefaultAsync(w => w.UserId == userLoginResponse.Result.UserId);

            if (worker == null)
            {
                response.Error = "Unable to Login";
                return response;
            }

            response.Success = true;

            response.Result = new WorkerAuthResponse
            {
                Id = worker.Id,
                UserId = userLoginResponse.Result.UserId,
                Token = userLoginResponse.Result.Token,
                BuffetId = worker.BuffetId,
                User = userLoginResponse.Result.User
            };

            return response;
        }

        public async Task<Response<List<GetWorkerDto>>> GetAll(WorkerPagedRequestDto dto,
            Expression<Func<Worker, bool>>? criteria = null)
        {
            var response = new Response<List<GetWorkerDto>>();

            var pageNumber = dto.PageNumber;

            var query = context.Workers.AsNoTracking();

            if (criteria != null)
            {
                query = query.Where(criteria);
            }

            const int pageSize = 3;

            if (pageNumber > 0)
            {
                response.TotalPages = (int)Math.Ceiling((double)query.Count() / pageSize);

                query = query.Skip((pageNumber - 1) * pageSize).Take(pageSize);
            }

            var workers = await query
                .Include(w => w.Buffet)
                .Include(w => w.User)
                .ToListAsync();

            response.Success = true;
            response.Result = mapper.Map<List<GetWorkerDto>>(workers);

            return response;
        }

        public async Task<Response<GetWorkerDto>> Update(UpdateWorkerDto dto)
        {
            var response = new Response<GetWorkerDto>();

            try
            {
                var worker = await context.Workers
                    .Include(w => w.User)
                    .Include(w => w.Buffet)
                    .FirstOrDefaultAsync(w => w.Id == dto.Id);

                if (worker == null)
                {
                    response.Error = "Worker Not Found";

                    return response;
                }

                var user = await userManager.FindByIdAsync(worker.UserId);

                if (user == null)
                {
                    response.Error = "Worker Not Found";

                    return response;
                }

                var updatedWorker = mapper.Map(dto, worker);

                user = updatedWorker.User;

                if (dto.User.Password != null && dto.User.Password.Trim().Length > 0)
                {
                    await userManager.RemovePasswordAsync(user);

                    user.PasswordHash = userManager.PasswordHasher.HashPassword(user, dto.User.Password);
                }

                await userManager.UpdateNormalizedUserNameAsync(user);

                await userManager.UpdateNormalizedEmailAsync(user);

                await userManager.UpdateAsync(user);

                context.Workers.Update(updatedWorker);

                await context.SaveChangesAsync();

                response.Result = mapper.Map<GetWorkerDto>(updatedWorker);
            }
            catch (Exception e)
            {
                response.Error = e.Message + "\n";
            }

            response.Success = true;

            return response;
        }

        public async Task<Response<bool>> Delete(int id)
        {
            var response = new Response<bool>();

            try
            {
                var worker = await context.Workers.FindAsync(id);

                if (worker == null)
                    response.Error = "Worker Not Found";
                else
                {
                    var user = await userManager.FindByIdAsync(worker.UserId);

                    if (user == null)
                    {
                        response.Error = "Worker Not Found";
                    }
                    else
                    {
                        await userManager.DeleteAsync(user);

                        await context.SaveChangesAsync();

                        response.Success = true;
                    }
                }
            }
            catch (Exception e)
            {
                response.Error = e.Message;
            }

            response.Success = true;

            response.Result = true;

            return response;
        }

        /*
         * SET ANSI_NULLS ON
            SET QUOTED_IDENTIFIER ON
            GO

            ALTER TRIGGER TRG_AfterDeleteWorker ON Workers
            AFTER DELETE
            AS
            BEGIN
                DELETE FROM AspNetUsers
                WHERE Id IN (SELECT UserId FROM DELETED);
            END;
         */
    }
}