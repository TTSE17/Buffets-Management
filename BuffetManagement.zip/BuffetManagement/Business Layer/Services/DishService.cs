﻿using System.Linq.Expressions;
using AutoMapper;
using Business_Layer.Dto;
using Business_Layer.Dto.Dish;
using Business_Layer.IServices;
using Data_Access_Layer;
using Microsoft.EntityFrameworkCore;

namespace Business_Layer.Services;

public class DishService(IMapper mapper, AppDbContext context) : IDishService
{
    public async Task<Response<List<GetDishDto>>> GetAll(Expression<Func<Dish, bool>>? criteria = null)
    {
        var response = new Response<List<GetDishDto>>();

        var query = context.Dishes.AsNoTracking();

        if (criteria != null)
        {
            query = query.Where(criteria);
        }

        var dishes = await query.ToListAsync();

        response.Result = mapper.Map<List<GetDishDto>>(dishes);

        response.Success = true;

        return response;
    }

    public async Task<Response<GetDishDto>> Add(CreateUpdateDishDto dto)
    {
        var response = new Response<GetDishDto>();

        try
        {
            var dishToAdd = mapper.Map<Dish>(dto);

            var dish = await context.Dishes.AddAsync(dishToAdd);

            await context.SaveChangesAsync();

            response.Result = mapper.Map<GetDishDto>(dish.Entity);

            response.Success = true;
        }
        catch (Exception e)
        {
            response.Error = e.Message;
        }

        return response;
    }

    public async Task<Response<GetDishDto>> Update(CreateUpdateDishDto dto)
    {
        var response = new Response<GetDishDto>();

        try
        {
            var dishToUpdate = await context.Dishes.FindAsync(dto.Id);

            if (dishToUpdate == null)
            {
                response.Error = "Dish could not be found";

                return response;
            }

            var dish = mapper.Map(dto, dishToUpdate);

            await context.SaveChangesAsync();

            response.Success = true;

            response.Result = mapper.Map<GetDishDto>(dish);
        }
        catch (Exception e)
        {
            response.Error = e.Message;
        }

        return response;
    }

    public async Task<Response<GetDishDto>> GetDetails(int id)
    {
        var response = new Response<GetDishDto>();

        var query = context.Dishes.AsNoTracking().Where(i => i.Id == id);

        if (!query.Any())
        {
            response.Error = $"Dish {id} does not exist";
            return response;
        }

        var items = await query.FirstAsync();

        response.Result = mapper.Map<GetDishDto>(items);

        response.Success = true;

        return response;
    }

    public async Task<Response<bool>> Delete(int id)
    {
        var response = new Response<bool>();

        try
        {
            var dishToDelete = await context.Dishes.FindAsync(id);

            if (dishToDelete == null)
                response.Error = "Dish could not be found";
            else
            {
                context.Dishes.Remove(dishToDelete);

                await context.SaveChangesAsync();

                response.Success = true;
            }
        }
        catch (Exception e)
        {
            response.Error = e.Message;
        }

        response.Success = true;

        response.Result = true;

        return response;
    }

    public async Task<Response<bool>> AddSale(int dishId, int count)
    {
        var response = new Response<bool>();

        var dish = await context.Dishes.FindAsync(dishId);

        if (dish == null)
        {
            response.Error = "Dish could not be found";

            return response;
        }

        var dishSale = new DishSale
        {
            DishId = dishId,
            Count = count,
            Price = dish.Price,
            Cost = dish.Cost
        };

        await context.DishSales.AddAsync(dishSale);

        await context.SaveChangesAsync();

        response.Success = true;
        response.Result = true;

        return response;
    }

    public Response<object> Statistics(Expression<Func<DishSale, bool>>? criteria = null)
    {
        var response = new Response<object>();

        var query = context.DishSales.AsNoTracking();

        if (criteria != null)
        {
            query = query.Where(criteria);
        }

        var totalSales = 0;

        decimal revenue = 0;

        decimal netProfit = 0;

        foreach (var dish in query)
        {
            totalSales += dish.Count;

            revenue += dish.Price * dish.Count;

            netProfit += dish.Price * dish.Count - dish.Cost * dish.Count;
        }

        response.Result = new
        {
            totalSales, revenue, netProfit
        };

        response.Success = true;

        return response;
    }
}