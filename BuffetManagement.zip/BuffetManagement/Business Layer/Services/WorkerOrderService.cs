﻿using System.Linq.Expressions;
using AutoMapper;
using Business_Layer.Dto;
using Business_Layer.Dto.WorkerOrder;
using Business_Layer.IServices;
using Data_Access_Layer;
using Microsoft.EntityFrameworkCore;

namespace Business_Layer.Services;

public class WorkerOrderService(
    IMapper mapper,
    AppDbContext context,
    IItemService itemService,
    IFirebaseService firebaseService) : IWorkerOrderService
{
    public async Task<Response<GetWorkerOrderDto>> Add(CreateWorkerOrderDto dto)
    {
        var response = new Response<GetWorkerOrderDto>();

        await using var transaction = await context.Database.BeginTransactionAsync();

        try
        {
            var orderToAdd = mapper.Map<WorkerOrder>(dto);
            orderToAdd.CreatedDate = DateTime.Now;
            orderToAdd.Status = OrderStatus.Pending;

            var order = (await context.WorkerOrders.AddAsync(orderToAdd)).Entity;

            await context.SaveChangesAsync();


            var itemsDto = dto.Items;

            decimal totalCost = 0;

            List<GetWorkerOrderDetailDto> orderDetailDtos = [];

            foreach (var (itemId, quantity) in itemsDto)
            {
                var item = await context.Items
                    .Where(x => x.Id == itemId)
                    .Include(i => i.Unit)
                    .FirstOrDefaultAsync();

                if (item == null)
                    throw new Exception($"Item with id: {itemId} not found");

                var itemPriceHistory = await itemService.GetLastItemPriceHistory(itemId, dto.BuffetId);

                if (itemPriceHistory == null)
                    throw new Exception("Item not Pricing");

                var unitType = item.Unit.Type;
                var cost = itemPriceHistory.Cost ?? 1;

                totalCost += unitType * cost * quantity;

                var orderDetail = new WorkerOrderDetail
                {
                    WorkerOrderId = order.Id,
                    ItemId = itemId,
                    Quantity = quantity,
                    ItemPriceHistoryId = itemPriceHistory.Id
                };

                await context.WorkerOrderDetails.AddAsync(orderDetail);

                var orderDetailDto = mapper.Map<GetWorkerOrderDetailDto>(orderDetail);

                orderDetailDto.Item.Cost = itemPriceHistory.Cost ?? null;
                orderDetailDto.Item.Price = itemPriceHistory.Price ?? null;

                orderDetailDtos.Add(orderDetailDto);
            }

            orderToAdd.TotalCost = totalCost;

            var orderDto = mapper.Map<GetWorkerOrderDto>(order);

            orderDto.OrderDetails = orderDetailDtos;

            response.Result = orderDto;

            response.Success = true;

            await context.SaveChangesAsync();

            await transaction.CommitAsync();

            await firebaseService.NotifyAdmin("New worker order added", "");
        }
        catch (Exception e)
        {
            await transaction.RollbackAsync();

            response.Error = e.Message;
        }

        return response;
    }

    public async Task<Response<List<GetWorkerOrderDto>>> GetAll(int pageNumber,
        Expression<Func<WorkerOrder, bool>>? criteria = null)
    {
        var response = new Response<List<GetWorkerOrderDto>>();

        var query = context.WorkerOrders.AsNoTracking().AsQueryable();

        if (criteria != null)
        {
            query = query.Where(criteria);
        }

        const int pageSize = 3;

        if (pageNumber > 0)
        {
            response.TotalPages = (int)Math.Ceiling((double)query.Count() / pageSize);

            query = query.Skip((pageNumber - 1) * pageSize).Take(pageSize);
        }

        query = query
            .Include(o => o.Buffet)
            .Include(o => o.Worker)
            .ThenInclude(w => w.User)
            .OrderByDescending(o => o.Id);
        ;

        var orders = await query.ToListAsync();

        if (orders.Count == 0)
        {
            response.Result = [];

            return response;
        }

        var result = mapper.Map<List<GetWorkerOrderDto>>(orders);

        response.Result = result;

        response.Success = true;

        return response;
    }

    public async Task<Response<GetWorkerOrderDto?>> GetDetails(int orderId)
    {
        var response = new Response<GetWorkerOrderDto?>();

        var order = await context.WorkerOrders.AsNoTracking()
            .Where(o => o.Id == orderId)
            .Include(o => o.Buffet)
            .Include(o => o.Worker)
            .ThenInclude(w => w.User)
            .FirstOrDefaultAsync();

        if (order is null)
        {
            response.Error = $"Order with id: {orderId} not found";

            return response;
        }

        order.OrderDetails = await context.WorkerOrderDetails.Where(o => o.WorkerOrderId == orderId)
            .Include(i => i.Item)
            .ThenInclude(i => i.Unit)
            .Include(i => i.Item)
            .ThenInclude(i => i.Category)
            .ToListAsync();

        var result = mapper.Map<GetWorkerOrderDto>(order);

        foreach (var orderDetail in result.OrderDetails)
        {
            var priceHistory = await itemService.GetPriceHistory(orderDetail.ItemPriceHistoryId);
            orderDetail.Item.Cost = priceHistory?.Cost;
        }

        response.Result = result;

        response.Success = true;

        return response;
    }

    public async Task<Response<GetWorkerOrderDto>> SetStatus(int id, OrderStatus status)
    {
        var response = new Response<GetWorkerOrderDto>();

        var order = await context.WorkerOrders.FindAsync(id);

        if (order == null)
        {
            response.Error = "Order not found";
            return response;
        }

        var orderStatus = order.Status;

        if (orderStatus == status)
        {
            response.Result = mapper.Map<GetWorkerOrderDto>(order);

            response.Success = true;

            return response;
        }

        if (orderStatus is OrderStatus.Completed or OrderStatus.Canceled)
        {
            response.Error = "You cannot change order status";

            return response;
        }

        if (status == OrderStatus.Completed)
        {
            // Response = (new orderDetailController())->UpdateQuantityInRepository(OrderID);
        }

        order.Status = status;

        await context.SaveChangesAsync();

        response.Result = mapper.Map<GetWorkerOrderDto>(order);

        response.Success = true;

        await firebaseService.NotifyWorkers("Update Order Status", status.ToString(), order.BuffetId);

        return response;
    }
}

/* Order Service :
 // preparing , delivering , completed
OrderStatus = Order->status;

if (OrderStatus == Value) {
    return response()->json(['Message' => "Update Successfully"], 202);
} else if (OrderStatus == 'preparing' && Value == 'completed') {
    return response()->json(['Error' => 'The Status cannot be changed from preparing to completed'], 400);
} else if (OrderStatus == 'delivering' && Value == 'preparing') {
    return response()->json(['Error' => 'The Status cannot be changed from delivering to preparing'], 400);
} else if (OrderStatus == 'completed') {
    return response()->json(['Error' => "The Status cannot be changed from completed"], 400);
}

    Response = null;

    if (Value == "delivering") {
            Response = (new orderDetailController())->UpdateQuantityInRepository(OrderID);
        }
*/