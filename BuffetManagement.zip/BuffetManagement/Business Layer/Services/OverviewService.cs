﻿using Business_Layer.Dto;
using Business_Layer.Dto.Overview;
using Business_Layer.IServices;
using Data_Access_Layer;
using Microsoft.EntityFrameworkCore;

namespace Business_Layer.Services;

public class OverviewService(AppDbContext context, IInventoryService inventoryService) : IOverviewService
{
    public async Task<Response<object>> GetDashboardOverview(OverviewPagedRequestDto dto)
    {
        var response = new Response<object>();

        var inventoryResult = (await inventoryService.Statistics(dto))!.Value;

        var activeBuffets = await context.Buffets.AsNoTracking()
            .Where(b => b.StatusId == (int)BuffetStatus.Open)
            .CountAsync();

        var totalWorkers = await context.Workers.AsNoTracking().CountAsync();

        var orders = context.CustomerOrders.AsNoTracking();

        var totalOrders = await orders.CountAsync();

        var ordersToday = await orders.Where(o => o.CreatedDate >= DateTime.Now.Date).CountAsync();

        decimal boxValue = 0;

        if (dto.BuffetId.HasValue)
        {
            var buffet = await context.Buffets.AsNoTracking().Where(b => b.Id == dto.BuffetId).FirstOrDefaultAsync();

            if (buffet != null)
                boxValue = buffet.BoxValue;
        }

        response.Result = new
        {
            inventoryResult.TotalSales,
            inventoryResult.NetProfit,
            inventoryResult.TopSelling,
            inventoryResult.SpoilageLoss,
            activeBuffets,
            totalWorkers,
            totalOrders,
            ordersToday,
            boxValue
        };


        response.Success = true;

        return response;
    }

    public async Task<Response<object>> Report(OverviewPagedRequestDto dto)
    {
        var response = new Response<object>();

        var inventoryResult = (await inventoryService.Statistics(dto))!.Value;

        var buffets = await context.Buffets.AsNoTracking().ToListAsync();

        List<object> salesBuffets = new();

        var sellingItems = await inventoryService.GetSellingItems(dto);

        var totalOrders = await context.CustomerOrders.AsNoTracking().CountAsync();

        foreach (var buffet in buffets)
        {
            dto.BuffetId = buffet.Id;
            
            var inventoryBuffetResult = (await inventoryService.Statistics(dto))!.Value;

            var totalOrdersInBuffet = await context.CustomerOrders.AsNoTracking()
                .Where(o => o.BuffetId == buffet.Id)
                .CountAsync();

            salesBuffets.Add(new { buffet.Name, Revenue = inventoryBuffetResult.TotalSales, totalOrdersInBuffet });
        }
        
        response.Result = new
        {
            totalOrders,
            inventoryResult.TotalSales,
            inventoryResult.NetProfit,
            inventoryResult.TopSelling,
            inventoryResult.SpoilageLoss,
            sellingItems,
            salesBuffets,
        };


        response.Success = true;

        return response;
    }

    // (Selling Price - Cost) / Selling Price × 100. 
}