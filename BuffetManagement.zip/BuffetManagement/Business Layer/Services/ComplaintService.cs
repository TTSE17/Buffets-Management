﻿using System.Linq.Expressions;
using AutoMapper;
using Business_Layer.Dto;
using Business_Layer.Dto.Complaint;
using Business_Layer.IServices;
using Data_Access_Layer;
using Microsoft.EntityFrameworkCore;

namespace Business_Layer.Services;

public class ComplaintService(
    IMapper mapper,
    AppDbContext context,
    IFirebaseService firebaseService) : IComplaintService
{
    public async Task<Response<List<GetComplaintDto>>> GetAll(Expression<Func<Complaint, bool>>? criteria = null)
    {
        var response = new Response<List<GetComplaintDto>>();

        var query = context.Complaints.AsNoTracking();

        if (criteria != null)
        {
            query = query.Where(criteria);
        }

        query = query
            .Include(c => c.User)
            .Include(c => c.Buffet);

        var complaints = await query.ToListAsync();

        response.Result = mapper.Map<List<GetComplaintDto>>(complaints);

        response.Success = true;

        return response;
    }

    public async Task<Response<GetComplaintDto>> Add(GetComplaintDto dto)
    {
        var response = new Response<GetComplaintDto>();

        try
        {
            var complaintToAdd = mapper.Map<Complaint>(dto);

            var complaint = await context.Complaints.AddAsync(complaintToAdd);

            await context.SaveChangesAsync();

            await firebaseService.NotifyAdmin("New Complaint",
                complaintToAdd.Title + " : " + complaintToAdd.Description);

            response.Result = mapper.Map<GetComplaintDto>(complaint.Entity);

            response.Success = true;
        }
        catch (Exception e)
        {
            response.Error = e.Message;
        }

        return response;
    }

    public async Task<Response<GetComplaintDto>> SetStatus(int id, string status)
    {
        var response = new Response<GetComplaintDto>();

        var complaint = await context.Complaints.FindAsync(id);

        if (complaint == null)
        {
            response.Error = "Complaint not found";
            return response;
        }

        complaint.Status = status;

        await context.SaveChangesAsync();

        await firebaseService.NotifyUser("Update Complaint Status", status, complaint.UserId);

        response.Result = mapper.Map<GetComplaintDto>(complaint);

        response.Success = true;

        return response;
    }
    
    public async Task<Response<GetComplaintDto>> GetDetails(int id)
    {
        var response = new Response<GetComplaintDto>();

        var query = context.Complaints.AsNoTracking().Where(c => c.Id == id);

        if (!query.Any())
        {
            response.Error = $"Complaint {id} does not exist";
            return response;
        }

        var complaint = await query
            .Include(c => c.Buffet)
            .Include(c => c.User)
            .FirstAsync();

        response.Result = mapper.Map<GetComplaintDto>(complaint);

        response.Success = true;

        return response;
    }

    public async Task<Response<bool>> Delete(int id)
    {
        var response = new Response<bool>();

        try
        {
            var complaintToDelete = await context.Complaints.FindAsync(id);

            if (complaintToDelete == null)
                response.Error = "Complaints could not be found";
            else
            {
                context.Complaints.Remove(complaintToDelete);

                await context.SaveChangesAsync();

                response.Success = true;
            }
        }
        catch (Exception e)
        {
            response.Error = e.Message;
        }

        return response;
    }
}