﻿using AutoMapper;
using Business_Layer.Dto;
using Business_Layer.Dto.Category;
using Business_Layer.IServices;
using Data_Access_Layer;
using Microsoft.EntityFrameworkCore;

namespace Business_Layer.Services;

public class CategoryService(IMapper mapper, AppDbContext context) : ICategoryService
{
    public async Task<Response<List<GetCategoryDto>>> GetAll()
    {
        var response = new Response<List<GetCategoryDto>>();

        var buffets = await context.Categories.ToListAsync();

        response.Success = true;
        response.Result = mapper.Map<List<GetCategoryDto>>(buffets);

        return response;
    }

    public async Task<Response<GetCategoryDto>> Add(GetCategoryDto dto)
    {
        var response = new Response<GetCategoryDto>();

        try
        {
            var categoryToAdd = mapper.Map<Category>(dto);

            var category = await context.Categories.AddAsync(categoryToAdd);

            await context.SaveChangesAsync();

            response.Success = true;

            response.Result = mapper.Map<GetCategoryDto>(category.Entity);
        }
        catch (Exception e)
        {
            response.Error = e.Message;
        }

        return response;
    }

    public async Task<Response<GetCategoryDto>> Update(GetCategoryDto dto)
    {
        var response = new Response<GetCategoryDto>();

        try
        {
            var categoryToUpdate = await context.Categories.FindAsync(dto.Id);

            if (categoryToUpdate == null)
            {
                response.Error = "Categroy could not be found";

                return response;
            }

            var category = mapper.Map(dto, categoryToUpdate);

            await context.SaveChangesAsync();

            response.Success = true;

            response.Result = mapper.Map<GetCategoryDto>(category);
        }
        catch (Exception e)
        {
            response.Error = e.Message;
        }

        return response;
    }
        
    public async Task<Response<bool>> Delete(int id)
    {
        var response = new Response<bool>();

        try
        {
            var category = await context.Categories.FindAsync(id);

            if (category == null)
                response.Error = "Category could not be found";
            else
            {
                context.Categories.Remove(category);

                await context.SaveChangesAsync();

                response.Success = true;
            }
        }
        catch (Exception e)
        {
            response.Error = e.Message;
        }

        response.Success = true;

        response.Result = true;

        return response;
    }

}