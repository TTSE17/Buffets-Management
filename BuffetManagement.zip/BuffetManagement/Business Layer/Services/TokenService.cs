﻿using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using Data_Access_Layer;
using Microsoft.AspNetCore.Identity;
using Microsoft.IdentityModel.Tokens;

namespace Business_Layer.Services
{
    public class TokenService(JwtOptions options, UserManager<User> userManager)
    {
        public async Task<string> CreateJwtToken(User user)
        {
            var tokenHandler = new JwtSecurityTokenHandler();

            var claims = new List<Claim>
            {
                new(ClaimTypes.NameIdentifier, user.Id),
                new(ClaimTypes.Name, user.UserName!),
                new(ClaimTypes.Email, user.Email!)
            };

            var roles = await userManager.GetRolesAsync(user);
            foreach (var role in roles)
            {
                claims.Add(new Claim(ClaimTypes.Role, role));
            }

            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Issuer = options.Issuer,
                Audience = options.Audience,


                Subject = new ClaimsIdentity
                (
                    claims
                ),

                Expires = DateTime.UtcNow.AddMinutes(options.LifeTime),

                SigningCredentials = new SigningCredentials
                (
                    new SymmetricSecurityKey(Encoding.UTF8.GetBytes(options.SigningKey)),
                    SecurityAlgorithms.HmacSha256
                ),
            };
            SecurityToken securityToken = tokenHandler.CreateToken(tokenDescriptor);
            return tokenHandler.WriteToken(securityToken);
        }

        public bool ValidateToken(string token, out JwtSecurityToken? jwtToken)
        {
            jwtToken = null;

            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(options.SigningKey));

            var tokenHandler = new JwtSecurityTokenHandler();

            try
            {
                var validationParameters = new TokenValidationParameters
                {
                    ValidateIssuer = true,
                    ValidIssuer = options.Issuer,

                    ValidateAudience = true,
                    ValidAudience = options.Audience,

                    ValidateIssuerSigningKey = true,
                    IssuerSigningKey = key,

                    ValidateLifetime = false,
                    ClockSkew = TimeSpan.Zero
                };

                tokenHandler.ValidateToken(token, validationParameters, out var validatedToken);

                jwtToken = validatedToken as JwtSecurityToken;

                return jwtToken != null;
            }
            catch (Exception)
            {
                Console.WriteLine(jwtToken);
                return false;
            }
        }
    }
}