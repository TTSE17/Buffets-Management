﻿using System.Linq.Expressions;
using AutoMapper;
using Business_Layer.Dto;
using Business_Layer.Dto.Supplier;
using Business_Layer.IServices;
using Data_Access_Layer;
using Microsoft.EntityFrameworkCore;

namespace Business_Layer.Services;

public class SupplierService(IMapper mapper, AppDbContext context) : ISupplierService
{
    public async Task<Response<List<GetSupplierDto>>> GetAll(Expression<Func<Supplier, bool>>? criteria = null)
    {
        var response = new Response<List<GetSupplierDto>>();

        var query = context.Suppliers.AsNoTracking();

        if (criteria != null)
        {
            query = query.Where(criteria);
        }

        var suppliers = await query.ToListAsync();

        response.Result = mapper.Map<List<GetSupplierDto>>(suppliers);

        response.Success = true;

        return response;
    }

    public async Task<Response<GetSupplierDto>> Add(CreateUpdateSupplierDto dto)
    {
        var response = new Response<GetSupplierDto>();

        try
        {
            var supplierToAdd = mapper.Map<Supplier>(dto);

            var supplier = await context.Suppliers.AddAsync(supplierToAdd);

            await context.SaveChangesAsync();

            response.Result = mapper.Map<GetSupplierDto>(supplier.Entity);

            response.Success = true;
        }
        catch (Exception e)
        {
            response.Error = e.Message;
        }

        return response;
    }

    public async Task<Response<GetSupplierDto>> Update(CreateUpdateSupplierDto dto)
    {
        var response = new Response<GetSupplierDto>();

        try
        {
            var supplierToUpdate = await context.Suppliers.FindAsync(dto.Id);

            if (supplierToUpdate == null)
            {
                response.Error = "Supplier could not be found";

                return response;
            }

            var supplier = mapper.Map(dto, supplierToUpdate);

            await context.SaveChangesAsync();

            response.Success = true;

            response.Result = mapper.Map<GetSupplierDto>(supplier);
        }
        catch (Exception e)
        {
            response.Error = e.Message;
        }

        return response;
    }

    public async Task<Response<bool>> Delete(int id)
    {
        var response = new Response<bool>();

        try
        {
            var supplier = await context.Suppliers.FindAsync(id);

            if (supplier == null)
                response.Error = "Supplier could not be found";
            else
            {
                context.Suppliers.Remove(supplier);

                await context.SaveChangesAsync();

                response.Result = true;

                response.Success = true;
            }
        }
        catch (Exception e)
        {
            response.Error = e.Message;
        }

        return response;
    }
}