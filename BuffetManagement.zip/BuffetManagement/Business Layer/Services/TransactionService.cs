﻿using System.Linq.Expressions;
using AutoMapper;
using Business_Layer.Dto;
using Business_Layer.Dto.CustomerOrder;
using Business_Layer.Dto.Transaction;
using Business_Layer.IServices;
using Data_Access_Layer;
using Microsoft.EntityFrameworkCore;

namespace Business_Layer.Services;

public class TransactionService(IMapper mapper, AppDbContext context, IBuffetService buffetService)
    : ITransactionService
{
    public async Task<Response<List<GetTransactionDto>>> GetAll(TransactionPagedRequestDto dto,
        Expression<Func<Transaction, bool>>? criteria = null)
    {
        var response = new Response<List<GetTransactionDto>>();

        const int pageSize = 3;

        var pageNumber = dto.PageNumber;

        var query = context.Transactions.AsNoTracking().AsQueryable();

        if (criteria != null)
        {
            query = query.Where(criteria);
        }

        if (pageNumber > 0)
        {
            response.TotalPages = (int)Math.Ceiling((double)query.Count() / pageSize);

            query = query.Skip((pageNumber - 1) * pageSize).Take(pageSize);
        }

        query = query
            .Include(d => d.User)
            .Include(d => d.Buffet);

        var transactions = await query.ToListAsync();

        if (transactions.Count == 0)
        {
            response.Result = [];

            return response;
        }

        var result = mapper.Map<List<GetTransactionDto>>(transactions);

        response.Result = result;

        response.Success = true;

        return response;
    }

    public async Task<Response<GetTransactionDto>> Add(GetTransactionDto dto)
    {
        var response = new Response<GetTransactionDto>();

        await using var tran = await context.Database.BeginTransactionAsync();

        try
        {
            var transactionToAdd = mapper.Map<Transaction>(dto);

            var boxResponse = await buffetService.AddValue(dto.BuffetId, dto.Value);

            if (!boxResponse.Success)
            {
                response.Error = boxResponse.Error;

                return response;
            }

            var transaction = await context.Transactions.AddAsync(transactionToAdd);

            await context.SaveChangesAsync();

            await tran.CommitAsync();

            response.Result = mapper.Map<GetTransactionDto>(transaction.Entity);

            response.Success = true;
        }
        catch (Exception e)
        {
            await tran.RollbackAsync();

            response.Error = e.Message;
        }

        return response;
    }
}