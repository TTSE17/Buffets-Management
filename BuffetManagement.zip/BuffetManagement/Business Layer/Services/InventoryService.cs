﻿using System.Linq.Expressions;
using AutoMapper;
using Business_Layer.Dto;
using Business_Layer.Dto.Inventory;
using Business_Layer.Dto.Item;
using Business_Layer.Dto.ItemPriceHistory;
using Business_Layer.Dto.Overview;
using Business_Layer.IServices;
using Data_Access_Layer;
using Microsoft.EntityFrameworkCore;

namespace Business_Layer.Services;

public class InventoryService(
    IMapper mapper,
    AppDbContext context,
    IItemService itemService,
    IWorkerService workerService) : IInventoryService
{
    public async Task<decimal?> CheckQuantity(int itemId, int buffetId)
    {
        var inventory = await context.Inventories.AsNoTracking()
                .Include(i => i.Item)
                .ThenInclude(i => i.Unit)
                .OrderByDescending(i => i.Id)
                .FirstOrDefaultAsync(i => i.ItemId == itemId && i.BuffetId == buffetId)
            ;

        if (inventory == null)
            return null;

        var unitType = inventory.Item.Unit.Type;
        var openQuantity = inventory.OpenQuantity;
        var closedQuantity = inventory.ClosedQuantity;

        var total = openQuantity + closedQuantity * unitType;

        return total;
    }

    public async Task<(decimal OpenQuantity, decimal ClosedQuantity)?> CalculateNewQuantity(
        int itemId, int buffetId, decimal amount)
    {
        var inventory = await context.Inventories.AsNoTracking()
            .Include(i => i.Item).ThenInclude(i => i.Unit)
            .OrderByDescending(i => i.Id)
            .FirstOrDefaultAsync(i => i.ItemId == itemId && i.BuffetId == buffetId);

        if (inventory == null)
            return null;

        var openQuantity = inventory.OpenQuantity;
        var unitType = inventory.Item.Unit.Type;
        var closedQuantity = inventory.ClosedQuantity;

        if (openQuantity >= amount)
        {
            openQuantity -= amount;

            return (openQuantity, closedQuantity);
        }

        if (unitType == 1)
        {
            var result = openQuantity + closedQuantity - amount;

            if (result < 0) return null;

            return (0, result);
        }

        decimal total = openQuantity;

        while (closedQuantity-- > 0)
        {
            total += unitType;

            if (total < amount) continue;

            openQuantity = total - amount;

            return (openQuantity, closedQuantity);
        }

        return null;
    }

    public async Task<Response<List<GetInventoryDto>>> GetAll(InventoryPagedRequestDto dto,
        Expression<Func<Inventory, bool>>? criteria = null)
    {
        var response = new Response<List<GetInventoryDto>>();

        var pageNumber = dto.PageNumber;

        const int pageSize = 3;

        var query = context.Inventories.AsNoTracking();

        if (criteria != null)
        {
            query = query.Where(criteria);
        }

        var query1 = query;

        query = query.AsSplitQuery() // Prevents cartesian product explosion
                .Where(i => i.Id == query1
                    .Where(x => x.ItemId == i.ItemId && x.BuffetId == i.BuffetId)
                    .OrderByDescending(x => x.Id)
                    .Select(x => x.Id)
                    .FirstOrDefault()
                )
                .OrderByDescending(x => x.Id)
            ;

        if (pageNumber > 0)
        {
            response.TotalPages = (int)Math.Ceiling((double)query.Count() / pageSize);

            query = query.Skip((pageNumber - 1) * pageSize).Take(pageSize);
        }

        if (!query.Any())
        {
            response.Success = true;

            response.Result = [];

            return response;
        }

        // query = query
        //     .Include(i => i.Buffet)
        //     .Include(i => i.Item)
        //     .ThenInclude(item => item.Category)
        //     .Include(i => i.Item)
        //     .ThenInclude(item => item.Unit)
        //     .GroupBy(i => new { i.ItemId, i.BuffetId })  
        //     .Select(g => g.OrderByDescending(x => x.Id).First())
        //     .AsQueryable();

        // var query1 = query;
        query = query
                .Include(i => i.Buffet)
                .Include(i => i.Item)
                .ThenInclude(item => item.Category)
                .Include(i => i.Item)
                .ThenInclude(item => item.Unit)
            // .AsSplitQuery() // Prevents cartesian product explosion
            // .Where(i => i.Id == query1
            //     .Where(x => x.ItemId == i.ItemId && x.BuffetId == i.BuffetId)
            //     .OrderByDescending(x => x.Id)
            //     .Select(x => x.Id)
            //     .FirstOrDefault()
            // )
            ;

        var buffets = await query.ToListAsync();

        var result = mapper.Map<List<GetInventoryDto>>(buffets);

        foreach (var inventoryDto in result)
        {
            var workerDto = await workerService.GetWorkerDto(inventoryDto.ByWorkerId);

            if (workerDto != null)
            {
                inventoryDto.WorkerName = workerDto.User.UserName;
            }

            var priceHistory = await itemService.GetPriceHistory(inventoryDto.ItemPriceHistoryId);

            if (priceHistory == null) continue;

            inventoryDto.Cost = priceHistory.Cost;
            inventoryDto.Price = priceHistory.Price;
        }

        response.Success = true;
        response.Result = result;

        return response;
    }

    public async Task<Response<GetItemHistoryDto>> GetItemHistory(InventoryPagedRequestDto dto,
        Expression<Func<Inventory, bool>>? criteria = null)
    {
        var response = new Response<GetItemHistoryDto>();

        var pageNumber = dto.PageNumber;

        const int pageSize = 3;

        var query = context.Inventories.AsNoTracking();

        if (criteria != null)
        {
            query = query.Where(criteria);
        }

        if (pageNumber > 0)
        {
            response.TotalPages = (int)Math.Ceiling((double)query.Count() / pageSize);

            query = query.Skip((pageNumber - 1) * pageSize).Take(pageSize);
        }

        if (!query.Any())
        {
            response.Success = true;

            return response;
        }

        query = query
                // .Include(i => i.Buffet)
                // .Include(i => i.Item)
                // .ThenInclude(item => item.Category)
                // .Include(i => i.Item)
                // .ThenInclude(item => item.Unit)
                .OrderByDescending(i => i.Id)
            ;

        var buffets = await query.ToListAsync();

        var result = mapper.Map<List<GetInventoryDto>>(buffets);

        var itemId = 0;

        foreach (var inventoryDto in result)
        {
            itemId = inventoryDto.ItemId;

            inventoryDto.WorkerName = (await workerService.GetWorkerDto(inventoryDto.ByWorkerId)).User.UserName;

            var priceHistory = await itemService.GetPriceHistory(inventoryDto.ItemPriceHistoryId);

            if (priceHistory == null) continue;

            inventoryDto.Cost = priceHistory.Cost;
            inventoryDto.Price = priceHistory.Price;
        }

        var item = await context.Items.AsNoTracking()
            .Where(i => i.Id == itemId)
            .Include(i => i.Unit)
            .Include(i => i.Category)
            .FirstAsync();

        response.Result = new GetItemHistoryDto
        {
            Item = mapper.Map<GetItemDto>(item),
            History = result
        };

        response.Success = true;

        return response;
    }

    public async Task<Response<GetInventoryDto>> Add(CreateInventoryDto dto)
    {
        var response = new Response<GetInventoryDto>();

        try
        {
            var inventoryToAdd = mapper.Map<Inventory>(dto);

            inventoryToAdd.LastUpdate = DateTime.Now;

            if (!dto.PriceHistoryId.HasValue)
            {
                var priceHistoryDto =
                    await itemService.GetLastItemPriceHistory(dto.ItemId, dto.BuffetId); // Not For Sandwich

                inventoryToAdd.ItemPriceHistoryId = priceHistoryDto!.Id;
            }
            else
            {
                inventoryToAdd.ItemPriceHistoryId = dto.PriceHistoryId.Value;
            }

            var item = await context.Inventories.AddAsync(inventoryToAdd);

            await context.SaveChangesAsync();

            response.Success = true;

            response.Result = mapper.Map<GetInventoryDto>(item.Entity);
        }
        catch (Exception e)
        {
            response.Error = e.Message;
        }

        return response;
    }

    public async Task<Response<GetInventoryDto>> Update(UpdateInventoryDto dto)
    {
        var response = new Response<GetInventoryDto>();

        try
        {
            var inventoryToUpdate = await context.Inventories.FindAsync(dto.Id);

            if (inventoryToUpdate == null)
            {
                response.Error = "Inventory Not Found";

                return response;
            }

            inventoryToUpdate = mapper.Map(dto, inventoryToUpdate);

            inventoryToUpdate.LastUpdate = DateTime.Now;

            await context.SaveChangesAsync();

            response.Success = true;

            response.Result = mapper.Map<GetInventoryDto>(inventoryToUpdate);
        }
        catch (Exception e)
        {
            response.Error = e.Message;
        }

        return response;
    }

    public async Task<Response<bool>> Delete(int id)
    {
        var response = new Response<bool>();

        try
        {
            var inventory = await context.Inventories.FindAsync(id);

            if (inventory == null)

                response.Error = "Record Not Found";
            else
            {
                context.Inventories.Remove(inventory);

                await context.SaveChangesAsync();

                response.Success = true;
            }
        }
        catch (Exception e)
        {
            response.Error = e.Message;
        }

        response.Success = true;

        response.Result = true;

        return response;
    }

    public async Task<Response<List<GetInventoryDto>>> AddSpoilageItem(AddSpoilageItemDto dto)
    {
        var response = new Response<List<GetInventoryDto>>();

        try
        {
            response.Result = [];

            var buffetId = dto.BuffetId;
            var byWorkerId = dto.ByWorkerId;

            var items = dto.Items;

            foreach (var (itemId, amount)in items)
            {
                var newQuantity = await CalculateNewQuantity(itemId, buffetId, amount);

                if (newQuantity == null)
                    throw new Exception($"Item {itemId} does not have enough quantity");

                var priceHistoryDto = await itemService.GetLastItemPriceHistory(itemId, buffetId);

                var inventoryToAdd = new Inventory
                {
                    BuffetId = buffetId,
                    ItemId = itemId,
                    ByWorkerId = byWorkerId,
                    SpoilageAmount = amount,
                    ClosedQuantity = newQuantity.Value.ClosedQuantity,
                    OpenQuantity = newQuantity.Value.OpenQuantity,
                    LastUpdate = DateTime.Now,
                    ItemPriceHistoryId = priceHistoryDto!.Id
                };

                var inventory = await context.Inventories.AddAsync(inventoryToAdd);

                await context.SaveChangesAsync();

                response.Result.Add(mapper.Map<GetInventoryDto>(inventory.Entity));
            }

            response.Success = true;
        }
        catch (Exception e)
        {
            response.Error = e.Message;
        }

        return response;
    }

    private async Task<(decimal TotalSales, decimal TotalCost)> GetSales(OverviewPagedRequestDto dto)
    {
        var buffetId = dto.BuffetId;

        var startDate = dto.StartDate;

        var endDate = dto.EndDate.HasValue
            ? dto.EndDate.Value.Date.AddDays(1).AddTicks(-1) // End of day
            : DateTime.Now.Date;

        var query = context.Inventories.AsNoTracking()
                .Where(i => !buffetId.HasValue || i.BuffetId == buffetId)
                .Where(i => !startDate.HasValue || (i.LastUpdate <= endDate && i.LastUpdate >= startDate.Value))
                .Include(i => i.Item)
                .ThenInclude(i => i.Unit)
            ;

        var sales = await query
            .Where(i => i.SpoilageAmount == null)
            .GroupBy(i => new { i.ItemId, i.BuffetId })
            .ToListAsync();

        decimal totalSales = 0;

        decimal totalCost = 0;

        foreach (var buffetItems in sales)
        {
            if (!buffetItems.Any()) continue;

            decimal? previousTotal = null;

            var inventories = buffetItems.OrderBy(i => i.Id);

            foreach (var inventory in inventories)
            {
                var unitType = inventory.Item.Unit.Type;
                var openQuantity = inventory.OpenQuantity;
                var closedQuantity = inventory.ClosedQuantity;

                var quantity = openQuantity + closedQuantity * unitType;

                if (previousTotal > quantity)
                {
                    var priceInfo = await itemService.GetPriceHistory(inventory.ItemPriceHistoryId);

                    if (priceInfo?.Price is null) continue;

                    var cost = priceInfo.Cost ?? 0;

                    totalCost += (previousTotal.Value - quantity) * cost;

                    var price = priceInfo.Price ?? 0;

                    totalSales += (previousTotal.Value - quantity) * price;
                }

                previousTotal = quantity;
            }
        }

        return (totalSales, totalCost);
    }

    public async Task<List<GetSellingItemDto>> GetSellingItems(
        OverviewPagedRequestDto dto)
    {
        var buffetId = dto.BuffetId;

        var startDate = dto.StartDate;

        var endDate = dto.EndDate.HasValue
            ? dto.EndDate.Value.Date.AddDays(1).AddTicks(-1) // End of day
            : DateTime.Now.Date;

        var query = context.Inventories.AsNoTracking()
            .Where(i => !buffetId.HasValue || i.BuffetId == buffetId)
            .Where(i => !startDate.HasValue || (i.LastUpdate <= endDate && i.LastUpdate >= startDate.Value))
            .Include(i => i.Item)
            .ThenInclude(i => i.Unit)
            .OrderByDescending(i => i.Id);

        var items = await query
            .Where(i => i.SpoilageAmount == null)
            .OrderByDescending(i => i.Id)
            .GroupBy(i => i.ItemId)
            .ToListAsync();

        List<GetSellingItemDto> sellingItems = [];

        foreach (var itemId in items)
        {
            decimal? previousTotal = null;

            decimal totalQuantity = 0;

            decimal totalSales = 0;

            var item = itemId.First().Item;

            var isRaw = false;

            GetItemPriceHistoryDto? lastItemPriceInfo = null;

            foreach (var inventory in itemId)
            {
                var unitType = inventory.Item.Unit.Type;
                var openQuantity = inventory.OpenQuantity;
                var closedQuantity = inventory.ClosedQuantity;

                var quantity = openQuantity + closedQuantity * unitType;

                if (previousTotal > quantity)
                {
                    var priceInfo = await itemService.GetPriceHistory(inventory.ItemPriceHistoryId);

                    if (priceInfo?.Price is null)
                    {
                        isRaw = true;

                        continue;
                    }

                    lastItemPriceInfo ??= priceInfo;

                    totalQuantity += quantity;

                    var price = priceInfo.Price ?? 0;

                    totalSales += (previousTotal.Value - quantity) * price;
                }

                previousTotal = quantity;
            }

            if (isRaw) continue;

            var sellingItem = new GetSellingItemDto
            {
                ItemName = item.Name,
                Revenue = totalSales,
                Sold = totalQuantity
            };

            if (lastItemPriceInfo is { Price: not null, Cost: not null })
            {
                sellingItem.Margin = (lastItemPriceInfo.Price.Value - lastItemPriceInfo.Cost.Value) /
                    lastItemPriceInfo.Price.Value * 100;
            }

            sellingItems.Add(sellingItem);
        }

        sellingItems = sellingItems.OrderByDescending(i => i.Sold).ThenByDescending(i => i.Revenue).ToList();

        return sellingItems;
    }

    public async Task<(decimal TotalSales, decimal NetProfit, string TopSelling, decimal SpoilageLoss)?>
        Statistics(OverviewPagedRequestDto dto)
    {
        var buffetId = dto.BuffetId;

        var startDate = dto.StartDate;

        var endDate = dto.EndDate.HasValue
            ? dto.EndDate.Value.Date.AddDays(1).AddTicks(-1) // End of day
            : DateTime.Now.Date;

        var query = context.Inventories.AsNoTracking()
            .Where(i => !buffetId.HasValue || i.BuffetId == buffetId)
            .Where(i => !startDate.HasValue || (i.LastUpdate <= endDate && i.LastUpdate >= startDate.Value))
            .Include(i => i.Item)
            .ThenInclude(i => i.Unit)
            .OrderByDescending(i => i.Id);

        // var sales = await query
        //     .Where(i => i.SpoilageAmount == null)
        //     .GroupBy(i => new { i.ItemId, i.BuffetId })
        //     .ToListAsync();
        //
        // decimal totalSales = 0;
        //
        // decimal totalCost = 0;
        //
        // foreach (var buffetItems in sales)
        // {
        //     if (!buffetItems.Any()) continue;
        //
        //     decimal? previousTotal = null;
        //
        //     foreach (var inventory in buffetItems)
        //     {
        //         var unitType = inventory.Item.Unit.Type;
        //         var openQuantity = inventory.OpenQuantity;
        //         var closedQuantity = inventory.ClosedQuantity;
        //
        //         var quantity = openQuantity + closedQuantity * unitType;
        //
        //         if (previousTotal == null)
        //         {
        //             previousTotal = quantity;
        //         }
        //         else if (previousTotal.Value > quantity)
        //         {
        //             var priceInfo = await itemService.GetPriceHistory(inventory.ItemPriceHistoryId);
        //
        //             if (priceInfo?.Price is null) continue;
        //
        //             var cost = priceInfo.Cost ?? 0;
        //
        //             totalCost += (previousTotal.Value - quantity) * cost;
        //
        //             var price = priceInfo?.Price ?? 0;
        //
        //             totalSales += (previousTotal.Value - quantity) * price;
        //         }
        //
        //         previousTotal = quantity;
        //     }
        // }

        var salesOverview = await GetSales(dto);

        var totalCost = salesOverview.TotalCost;

        var totalSales = salesOverview.TotalSales;

        var items = await query
            .Where(i => i.SpoilageAmount == null)
            .GroupBy(i => i.ItemId)
            .ToListAsync();

        decimal maxQuantity = 0;

        string topSelling = "";

        foreach (var itemId in items)
        {
            decimal? previousTotal = null;

            decimal totalQuantity = 0;

            var itemName = itemId.First().Item.Name;

            foreach (var inventory in itemId)
            {
                var unitType = inventory.Item.Unit.Type;
                var openQuantity = inventory.OpenQuantity;
                var closedQuantity = inventory.ClosedQuantity;

                var quantity = openQuantity + closedQuantity * unitType;

                if (previousTotal > quantity)
                {
                    var priceInfo = await itemService.GetPriceHistory(inventory.ItemPriceHistoryId);

                    if (priceInfo?.Price is null) continue;

                    totalQuantity += quantity;
                }

                previousTotal = quantity;
            }

            if (totalQuantity <= maxQuantity) continue;

            maxQuantity = totalQuantity;

            topSelling = itemName;
        }

        var spoilageItems = await query.Where(i => i.SpoilageAmount != null).ToListAsync();

        decimal totalSpoilage = 0;

        foreach (var inventory in spoilageItems)
        {
            var priceInfo = await itemService.GetPriceHistory(inventory.ItemPriceHistoryId);

            var cost = priceInfo?.Cost ?? 0;

            totalSpoilage += (inventory.SpoilageAmount ?? 0) * cost;
        }

        return (totalSales, totalSales - totalCost, topSelling, totalSpoilage);
    }
}